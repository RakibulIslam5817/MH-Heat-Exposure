# Extreme heat exposure and cooling center accessibility by housing types in U.S.
Analysis code accompanying the manuscript on building-level extreme heat exposure and public cooling center accessibility across manufactured, single-family and multi-family housing in the contiguous United States.

Author: Rakibul Islam, Department of Geography and Atmospheric Science, University of Kansas
        Yoonjung Ahn, Department of Geography and Atmospheric Science, University of Kansas

## Overview

The analysis compares extreme heat exposure and cooling center accessibility across three housing types at the level of individual building structures. Heat exposure is measured from PRISM daily maximum temperature at 800 m resolution for the April to October 2024 warm season. Distributional inequality is assessed with weighted cumulative distribution functions and Gini coefficients, and systematic within-county differences are estimated with county fixed-effects regression models.

## Repository structure

```
.
├── README.md
├── R/
│   ├── 00_setup.R                
│   ├── 01_build_sample.R         
│   ├── 02_heat_measures.R        
│   ├── 03_cdf_gini.R             
│   ├── 04_heat_figures.R         
│   ├── 05_acs_controls.R         
│   ├── 06_heat_regressions.R     
│   ├── 07_cooling_centers.R      
│   ├── 08_robustness.R           
│   └── 09_maps.R                 
├── data/                            
└── output/                         
```

## Running the analysis

Set the working directory to the project root, then source the scripts in order. Script `00_setup.R` must be sourced first in every session; the remaining scripts assume the objects it defines are present.

```r
setwd("/path/to/project")
source("R/00_setup.R")
source("R/01_build_sample.R")       # slow; see note below
source("R/02_heat_measures.R")
source("R/03_cdf_gini.R")
source("R/04_heat_figures.R")
source("R/05_acs_controls.R")
source("R/06_heat_regressions.R")
source("R/07_cooling_centers.R")
source("R/08_robustness.R")
source("R/09_maps.R")
```

Scripts `04_heat_figures.R` and `09_maps.R` reuse objects created by `03_cdf_gini.R` and `07_cooling_centers.R` respectively, so those scripts should be run in the same session.

Script `01_build_sample.R` reads the full structure inventory for all states and takes several hours. It writes each state's sample as it completes and skips states already written, so an interrupted run can be restarted. The combined sample it produces, `data/all_states_sample.csv`, is deposited alongside this code, so the remaining scripts can be run without repeating this step.

## Required input data

Place the following in `data/` before running.

| File or folder | Contents | Source |
|---|---|---|
| `structures/` | National structure inventory, one file geodatabase per state, in folders named `Deliverable<date><ST>/` | Yang et al. (2024) |
| `all_states_sample.csv` | County-stratified building sample with inverse probability weights | Produced by `01_build_sample.R`; deposited with this code |
| `PRISM_Raster/` | PRISM daily maximum temperature, 800 m, April to October 2024, one zip archive per day | PRISM Climate Group, Oregon State University |
| `cooling/*.gpkg` | Cooling center locations for 19 states | Jeon et al. (2025) |
| `cooling/Arizona_with_coordinates.csv` | Arizona cooling center locations | Maricopa Association of Governments Heat Relief Network |
| `cooling/*_with_coordinates.csv` | Cooling center locations compiled for this study (Texas, Louisiana, Florida, Alabama, South Carolina, North Carolina) | State and local government sources; deposited with this code |

The building sample is drawn from the national structure inventory of Yang et al. (2024) by `01_build_sample.R`. Buildings are classified from the inventory's `PRIM_OCC` field, with `Manufactured Home` mapped to MH, `Single Family Dwelling` to single-family and `Multi - Family Dwelling` to multi-family. Counties containing fewer than ten manufactured homes are excluded, because the within-county comparison the regression models rely on is not meaningful where manufactured housing is almost absent. In each remaining county, up to 500 buildings of each housing type are drawn at random under `set.seed(1234)`, and inverse probability weights are computed as the ratio of the total number of buildings of that type in the county to the number selected. The resulting file carries the fields `UUID`, `Building`, `PRIM_OCC`, `OCC_CLS`, `state_abbrev`, `state_fips`, `county_fips`, `CENSUSCODE`, `SQFEET`, `LATITUDE`, `LONGITUDE`, `total_n`, `selected_n` and `weight`.

American Community Survey estimates and Census boundary files are downloaded automatically through the `tidycensus` and `tigris` packages. American Community Survey estimates and Census boundary files are downloaded automatically through the tidycensus and tigris packages. The urban indicator is built from the 2020 Census Urban Area Blocks file, which 05_acs_controls.R downloads to data/2020_UA_BLOCKS.txt on first run and reuses thereafter.

## Census API key

`tidycensus` requires a Census API key, available at <https://api.census.gov/data/key_signup.html>. Store it in a `.Renviron` file in the project root rather than in the scripts:

```
CENSUS_API_KEY=your_key_here
```
## Software environment

Developed in R 4.4 on Windows. Required packages: `terra`, `sf`, `dplyr`, `tidyr`, `purrr`, `stringr`, `readr`, `ggplot2`, `scales`, `patchwork`, `cowplot`, `RColorBrewer`, `fixest`, `broom`, `tidycensus`, `tigris`, `reldist`, `spdep`, `RANN`.

Run `sessionInfo()` after sourcing `00_setup.R` and record the output alongside this deposit for exact version provenance.

## License

Code released under the MIT License. Input data remain subject to the terms of their original sources.
