

# 06_cooling_centers.R
# Cooling center accessibility: distances, coverage, regressions
#
# Cooling center sources:
#   Jeon et al. (2025), 20 states, GeoPackage files
#   Maricopa Association of Governments Heat Relief Network
#     (Arizona, replaces the Jeon et al. Arizona layer)
#   Locations compiled for this study from state and local
#     government sources for Texas, Louisiana, Florida, Alabama,
#     South Carolina and North Carolina
#
# Rhode Island is excluded because its manufactured housing
# stock is too small (fewer than 4,000 units). The accessibility
# analysis therefore covers 24 states.
#
# Distances are straight-line (Euclidean) in EPSG:5070 and are
# computed within state boundaries. 
#
# Inputs:
#   output/regression/analysis_dataset.csv
#   data/cooling/*.gpkg    Jeon et al. state layers
#   data/cooling/*.csv     compiled state files
#
# Outputs:
#   output/cdf_gini/national_cooling_coverage.csv
#   output/cdf_gini/gini_cooling_distance.csv
#   output/regression/cooling_reg_df.csv
#   output/regression/cooling_regression_results.csv  
#   output/maps/CDF_cooling_access_national.png       
#   output/cdf_gini/cooling_center_descriptives.png   
#
# Run 00_setup.R first.


###########################  Load the Jeon et al. GeoPackage layers ###########################
gpkg_states <- tribble(
  ~state_fips, ~state_abbrev, ~file_name,
  "04", "AZ", "arizona",
  "09", "CT", "connecticut",
  "17", "IL", "illinois",
  "18", "IN", "indiana",
  "06", "CA", "california",
  "27", "MN", "minnesota",
  "26", "MI", "michigan",
  "29", "MO", "missouri",
  "36", "NY", "newyork",
  "40", "OK", "oklahoma",
  "41", "OR", "oregon",
  "42", "PA", "pennsylvania",
  "47", "TN", "tennessee",
  "48", "TX", "texas",
  "50", "VT", "vermont",
  "51", "VA", "virginia",
  "53", "WA", "washington",
  "55", "WI", "wisconsin",
  "24", "MD", "maryland"
)

cat("Loading Jeon et al. cooling center layers...\n")

cooling_gpkg <- map_dfr(seq_len(nrow(gpkg_states)), function(i) {
  path <- file.path(dir_cooling,
                    paste0(gpkg_states$file_name[i],
                           "_cooling_centers.gpkg"))
  df <- st_read(path, quiet = TRUE) |>
    mutate(state_fips   = gpkg_states$state_fips[i],
           state_abbrev = gpkg_states$state_abbrev[i])
  cat("  ", gpkg_states$state_abbrev[i], "|", nrow(df), "\n")
  df
}) |>
  st_transform(crs = crs_albers)

########################### Load the compiled state files ###########################
# Arizona replaces the Jeon et al. layer entirely; Texas is
# supplemented; the remaining five states are new.

csv_states <- tribble(
  ~state_abbrev, ~state_fips, ~file_name,
  "AZ", "04", "Arizona_with_coordinates",
  "TX", "48", "Texas_with_coordinates",
  "LA", "22", "Louisiana_with_coordinates",
  "FL", "12", "Florida_with_coordinates",
  "AL", "01", "Alabama_with_coordinates",
  "SC", "45", "South_Carolina_with_coordinates",
  "NC", "37", "North_Carolina_with_coordinates"
)

# Columns present in the GeoPackage layers but not in the
# compiled files; padded with NA so the two sources bind cleanly
extra_cols <- c("state", "layer", "classification_source",
                "google_name", "google_address", "google_rating",
                "google_website", "google_phone", "google_types",
                "data_source", "data_provenance",
                "County", "City")

cat("\nLoading compiled cooling center files...\n")

cooling_csv <- map_dfr(seq_len(nrow(csv_states)), function(i) {

  df <- read_csv(
    file.path(dir_cooling,
              paste0(csv_states$file_name[i], ".csv")),
    show_col_types = FALSE) |>
    mutate(state_abbrev = csv_states$state_abbrev[i],
           state_fips   = csv_states$state_fips[i],
           STUSPS       = csv_states$state_abbrev[i])

  for (col in extra_cols) {
    if (!col %in% names(df)) df[[col]] <- NA
  }

  n_missing <- sum(is.na(df$Latitude) | is.na(df$Longitude))
  if (n_missing > 0) {
    cat("  ", csv_states$state_abbrev[i], "|",
        n_missing, "rows dropped (missing coordinates)\n")
  }

  df |>
    filter(!is.na(Latitude), !is.na(Longitude)) |>
    st_as_sf(coords = c("Longitude", "Latitude"),
             crs = crs_wgs84) |>
    st_transform(crs = crs_albers) |>
    rename(geom = geometry)
})

cooling_all <- bind_rows(
  cooling_gpkg |>
    filter(state_fips != "04") |>          # Arizona replaced
    mutate(google_rating = as.numeric(google_rating)),
  cooling_csv
)

cat("\nTotal cooling centers:",
    format(nrow(cooling_all), big.mark = ","), "\n")
cat("States:", n_distinct(cooling_all$state_abbrev), "\n")
cat("Empty geometries:", sum(st_is_empty(cooling_all)), "\n")

cooling_all |>
  st_drop_geometry() |>
  count(state_abbrev, state_fips) |>
  arrange(state_abbrev) |>
  print(n = 30)

########################### Buildings in covered states ###########################
analysis_df <- read_csv(
  file.path(dir_out, "regression", "analysis_dataset.csv"),
  col_types = cols(
    UUID        = col_character(),
    Building    = col_character(),
    state_fips  = col_character(),
    county_fips = col_character(),
    region      = col_character(),
    .default    = col_guess()
  ))

cooling_states <- cooling_all |>
  st_drop_geometry() |>
  distinct(state_fips, state_abbrev)

buildings_cooling <- analysis_df |>
  mutate(state_fips = formatC(as.integer(state_fips),
                              width = 2, flag = "0")) |>
  filter(state_fips %in% cooling_states$state_fips) |>
  st_as_sf(coords = c("LONGITUDE", "LATITUDE"),
           crs = crs_wgs84, remove = FALSE) |>
  st_transform(crs = crs_albers)

cat("\nBuildings in covered states:",
    format(nrow(buildings_cooling), big.mark = ","), "\n")

########################### Distance to the nearest cooling center ###########################
cat("\nComputing distances by state...\n")
t0 <- Sys.time()

dist_list <- map_dfr(cooling_states$state_fips, function(fips) {

  abbrev  <- cooling_states$state_abbrev[
               cooling_states$state_fips == fips]
  bldgs   <- buildings_cooling |> filter(state_fips == fips)
  cooling <- cooling_all       |> filter(state_fips == fips)

  if (nrow(bldgs) == 0 || nrow(cooling) == 0) {
    cat("  ", abbrev, "skipped\n"); return(NULL)
  }

  cat("  ", abbrev, "| buildings:", nrow(bldgs),
      "| centers:", nrow(cooling), "\n")

  nearest_idx <- st_nearest_feature(bldgs, cooling)
  dist_m      <- as.numeric(st_distance(
                   bldgs, cooling[nearest_idx, ],
                   by_element = TRUE))

  bldgs |>
    st_drop_geometry() |>
    select(UUID, Building, state_abbrev, state_fips, weight) |>
    mutate(
      dist_km       = dist_m / 1000,
      covered_walk  = as.integer(dist_km <= walk_threshold_km),
      covered_drive = as.integer(dist_km <= drive_threshold_km)
    )
})

cat("Done in:",
    round(difftime(Sys.time(), t0, units = "mins"), 1), "mins\n")
cat("Total buildings:",
    format(nrow(dist_list), big.mark = ","), "\n")

########################### Coverage summary and Gini ###########################
coverage_summary <- dist_list |>
  group_by(Building) |>
  summarise(
    n              = n(),
    pct_walk       = round(weighted.mean(covered_walk, weight,
                                          na.rm = TRUE) * 100, 1),
    pct_drive      = round(weighted.mean(covered_drive, weight,
                                          na.rm = TRUE) * 100, 1),
    median_dist_km = round(median(dist_km, na.rm = TRUE), 2),
    mean_dist_km   = round(mean(dist_km, na.rm = TRUE), 2),
    .groups = "drop"
  )

print(coverage_summary)

write.csv(coverage_summary,
  file.path(dir_out, "cdf_gini", "national_cooling_coverage.csv"),
  row.names = FALSE)

gini_cooling <- compute_group_gini(
  dist_list |> mutate(Building = factor(Building,
                                        levels = building_levels)),
  "dist_km") |>
  mutate(Group = factor(Group,
                        levels = c("All buildings",
                                   building_levels))) |>
  arrange(Group)

cat("\nCooling distance Gini:\n")
print(gini_cooling)

write.csv(gini_cooling,
  file.path(dir_out, "cdf_gini", "gini_cooling_distance.csv"),
  row.names = FALSE)

########################### CDF and coverage bars ###########################
cdf_cooling <- dist_list |>
  mutate(Building = factor(Building, levels = building_levels)) |>
  group_by(Building) |>
  group_modify(~ weighted_cdf(.x$dist_km, .x$weight)) |>
  ungroup()

gini_val <- gini_cooling |>
  filter(Group == "All buildings") |>
  pull(gini) |>
  round(2)

p_cdf <- ggplot(cdf_cooling,
                aes(x = x, y = cdf, color = Building)) +
  geom_step(linewidth = 0.9) +
  geom_vline(xintercept = walk_threshold_km, linetype = "dashed",
             color = "grey30", linewidth = 0.6) +
  geom_vline(xintercept = drive_threshold_km, linetype = "dotted",
             color = "grey30", linewidth = 0.6) +
  annotate("text", x = walk_threshold_km, y = 0.80,
           label = "0.8 km\nwalk", hjust = -0.1, size = 3.0,
           color = "grey30") +
  annotate("text", x = drive_threshold_km, y = 0.68,
           label = "16.1 km\ndrive", hjust = -0.1, size = 3.0,
           color = "grey30") +
  annotate("text", x = 500, y = 0.06,
           label = paste0("Gini = ", gini_val),
           hjust = 2, size = 3.4, color = "grey15") +
  scale_color_manual(name = "Building type:",
                     values = building_colors) +
  scale_x_continuous(
    limits = c(0, 600),
    breaks = c(0, 20, 50, 100, 200, 300, 400, 500, 600),
    expand = expansion(mult = c(0.01, 0.02))) +
  scale_y_continuous(breaks = seq(0, 1, 0.25), limits = c(0, 1),
                     expand = expansion(mult = c(0.01, 0.01))) +
  labs(x = "Distance (km)", y = "Cumulative Proportion") +
  theme_classic() +
  theme(
    axis.title       = element_text(size = 10),
    axis.text        = element_text(size = 9, color = "black"),
    legend.position  = "bottom",
    legend.direction = "horizontal",
    legend.text      = element_text(size = 10),
    legend.title     = element_text(size = 10),
    legend.key.width = unit(1.2, "cm"),
    plot.background  = element_rect(fill = "white", color = NA))

bar_data <- coverage_summary |>
  select(Building, pct_walk, pct_drive) |>
  pivot_longer(cols = c(pct_walk, pct_drive),
               names_to = "threshold", values_to = "pct") |>
  mutate(
    threshold = factor(threshold,
                       levels = c("pct_walk", "pct_drive"),
                       labels = c("Walking (0.8 km)",
                                  "Driving (16.1 km)")),
    Building  = factor(Building, levels = building_levels))

p_bar <- ggplot(bar_data,
                aes(x = Building, y = pct, fill = Building)) +
  geom_col(width = 0.5, show.legend = FALSE) +
  geom_text(aes(label = paste0(pct, "%")), vjust = -0.4,
            size = 3.5, fontface = "bold") +
  facet_wrap(~ threshold, ncol = 2) +
  scale_fill_manual(values = building_colors) +
  scale_y_continuous(limits = c(0, 105), breaks = seq(0, 100, 25),
                     labels = function(x) paste0(x, "%")) +
  labs(x = NULL, y = "% of Buildings Covered") +
  theme_classic() +
  theme(
    axis.title.y     = element_text(size = 10),
    axis.text        = element_text(size = 9, color = "black"),
    strip.text       = element_text(size = 10, face = "bold"),
    strip.background = element_rect(fill = "grey92", color = NA),
    plot.background  = element_rect(fill = "white", color = NA))

final_cooling <- (p_cdf / p_bar) +
  plot_layout(heights = c(1.6, 1)) +
  plot_annotation(tag_levels = "a", tag_suffix = ")") &
  theme(plot.tag          = element_text(size = 12,
                                          face = "bold"),
        plot.tag.position = c(0, 1.03),
        plot.margin       = margin(16, 5.5, 5.5, 12))

ggsave(file.path(dir_out, "maps",
                 "CDF_cooling_access_national.png"),
       plot = final_cooling, width = 8, height = 10,
       dpi = 400, bg = "white")

cat("\nSaved CDF_cooling_access_national.png\n")

########################### Accessibility regressions ###########################
# Model 1: log distance to the nearest cooling center, OLS
# Model 2: binary walking access indicator, linear probability
# Both with county fixed effects and county-clustered errors.

cooling_reg_df <- dist_list |>
  left_join(
    analysis_df |>
      select(UUID, county_fips, region, LATITUDE, LONGITUDE,
             all_of(controls)) |>
      mutate(county_fips = formatC(as.integer(county_fips),
                                   width = 5, flag = "0")),
    by = "UUID") |>
  mutate(
    Building = factor(Building, levels = building_levels),
    log_dist = log(dist_km)
  ) |>
  filter(!is.na(county_fips), !is.na(log_dist),
         !is.na(covered_walk),
         if_all(all_of(controls), ~ !is.na(.x)))

# No building sits exactly at a cooling center, so no offset is
# needed before the log transform
stopifnot(min(cooling_reg_df$dist_km) > 0)

cat("\nCooling regression rows:",
    format(nrow(cooling_reg_df), big.mark = ","), "\n")

write.csv(cooling_reg_df,
  file.path(dir_out, "regression", "cooling_reg_df.csv"),
  row.names = FALSE)

make_cooling_pair <- function(comparison_type) {
  cooling_reg_df |>
    filter(Building %in% c("MH", comparison_type)) |>
    mutate(Building    = factor(Building,
                                levels = c(comparison_type, "MH")),
           county_fips = factor(county_fips))
}

cooling_mh_sf <- make_cooling_pair("Single Family")
cooling_mh_mf <- make_cooling_pair("Multi-Family")

fml_log_dist <- as.formula(paste0(
  "log_dist ~ Building + ", control_formula, " | county_fips"))
fml_walk <- as.formula(paste0(
  "covered_walk ~ Building + ", control_formula, " | county_fips"))

fit_cooling <- function(fml, data) {
  feols(fml, data = data, weights = ~ weight,
        cluster = ~ county_fips, fixef.rm = "singleton")
}

cat("\nFitting cooling accessibility models...\n")

m_sf_log  <- fit_cooling(fml_log_dist, cooling_mh_sf)
m_sf_walk <- fit_cooling(fml_walk,     cooling_mh_sf)
m_mf_log  <- fit_cooling(fml_log_dist, cooling_mh_mf)
m_mf_walk <- fit_cooling(fml_walk,     cooling_mh_mf)

extract_cooling <- function(model, outcome_label,
                             comparison_label) {
  fs <- fitstat(model, type = c("r2", "wr2", "ar2", "rmse", "n"))

  tidy(model, conf.int = TRUE) |>
    filter(str_detect(term, "BuildingMH")) |>
    mutate(
      comparison = comparison_label,
      outcome    = outcome_label,
      sig        = sig_stars(p.value),
      n_obs      = as.integer(fs$n),
      r2_within  = as.numeric(fs$wr2),
      r2_overall = as.numeric(fs$r2),
      r2_adj     = as.numeric(fs$ar2),
      rmse       = as.numeric(fs$rmse),
      # For the log distance model, exp(beta) - 1 is the
      # percentage difference in the geometric mean distance
      pct_diff   = ifelse(outcome_label == "log(dist_km)",
                          round((exp(estimate) - 1) * 100, 2),
                          NA_real_)
    ) |>
    select(comparison, outcome, estimate, std.error, statistic,
           p.value, sig, conf.low, conf.high, pct_diff,
           n_obs, r2_within, r2_overall, r2_adj, rmse) |>
    mutate(across(where(is.numeric) & !any_of("p.value"),
                  ~ round(.x, 4)))
}

cooling_results <- bind_rows(
  extract_cooling(m_sf_log,  "log(dist_km)",
                  "MH vs Single Family"),
  extract_cooling(m_sf_walk, "covered_walk",
                  "MH vs Single Family"),
  extract_cooling(m_mf_log,  "log(dist_km)",
                  "MH vs Multi-Family"),
  extract_cooling(m_mf_walk, "covered_walk",
                  "MH vs Multi-Family")
)

cat("\nCooling accessibility results (Table 5):\n")
print(cooling_results, width = Inf)

write.csv(cooling_results,
  file.path(dir_out, "regression",
            "cooling_regression_results.csv"),
  row.names = FALSE)

# ----cooling center descriptives ------------------
cooling_desc <- cooling_all |>
  st_drop_geometry() |>
  mutate(
    ownership = case_when(
      is.na(public_private) | str_trim(public_private) == "" ~
        "Unknown",
      TRUE ~ str_to_title(str_trim(public_private))),
    category  = case_when(
      is.na(detailed_category) |
        str_trim(detailed_category) == "" ~ "Unknown",
      TRUE ~ str_to_title(str_trim(detailed_category)))
  )

pp_summary <- cooling_desc |>
  count(ownership, name = "n") |>
  mutate(pct = round(n / sum(n) * 100, 1)) |>
  arrange(desc(n))

cat_summary <- cooling_desc |>
  count(category, name = "n") |>
  mutate(pct = round(n / sum(n) * 100, 1)) |>
  arrange(desc(n))

state_summary <- cooling_desc |>
  group_by(state_abbrev) |>
  summarise(
    n_total   = n(),
    n_public  = sum(ownership == "Public"),
    n_private = sum(ownership == "Private"),
    n_unknown = sum(ownership == "Unknown"),
    .groups   = "drop") |>
  arrange(desc(n_total))

cat("\nCooling centers by ownership:\n")
print(pp_summary)
cat("\nTop 15 facility types:\n")
print(head(cat_summary, 15))

pp_colors <- c("Public"  = "#185FA5",
               "Private" = "#C0392B",
               "Unknown" = "#AAAAAA")

t_desc <- theme_classic() + theme(
  plot.title      = element_text(size = 13, face = "bold",
                                  hjust = 0.5),
  axis.title      = element_text(size = 11),
  axis.text       = element_text(size = 10, color = "black"),
  legend.position = "none",
  plot.background = element_rect(fill = "white", color = NA))

pA <- pp_summary |>
  ggplot(aes(x = reorder(ownership, -n), y = n, fill = ownership)) +
  geom_col(width = 0.6, alpha = 0.85) +
  geom_text(aes(label = paste0(format(n, big.mark = ","),
                               "\n(", pct, "%)")),
            vjust = -0.4, size = 4) +
  scale_fill_manual(values = pp_colors) +
  scale_y_continuous(labels = comma,
                     expand = expansion(mult = c(0, 0.2))) +
  t_desc +
  labs(title = "Cooling Centers by Ownership",
       x = NULL, y = "Number of facilities")

pB <- cat_summary |>
  filter(category != "Unknown") |>
  head(15) |>
  ggplot(aes(x = reorder(category, n), y = n)) +
  geom_col(fill = "#185FA5", alpha = 0.8, width = 0.7) +
  geom_text(aes(label = paste0(format(n, big.mark = ","),
                               " (", pct, "%)")),
            hjust = -0.05, size = 3.8) +
  coord_flip() +
  scale_y_continuous(labels = comma,
                     expand = expansion(mult = c(0, 0.3))) +
  t_desc +
  labs(title = "Cooling Center Types (Top 15)",
       x = NULL, y = "Number of facilities")

state_levels <- state_summary |>
  filter(!is.na(state_abbrev)) |>
  arrange(n_total) |>
  pull(state_abbrev)

pC <- state_summary |>
  filter(!is.na(state_abbrev)) |>
  pivot_longer(cols = c(n_public, n_private, n_unknown),
               names_to = "type", values_to = "n") |>
  mutate(
    type = recode(type, n_public = "Public",
                  n_private = "Private", n_unknown = "Unknown"),
    type = factor(type, levels = c("Public", "Private",
                                   "Unknown")),
    state_abbrev = factor(state_abbrev, levels = state_levels)) |>
  ggplot(aes(x = state_abbrev, y = n, fill = type)) +
  geom_col(width = 0.75, alpha = 0.85) +
  coord_flip() +
  scale_fill_manual(name = "Ownership:", values = pp_colors) +
  scale_y_continuous(labels = comma,
                     expand = expansion(mult = c(0, 0.05))) +
  t_desc +
  theme(axis.text.y      = element_text(size = 9,
                                         color = "black"),
        legend.position  = "bottom",
        legend.direction = "horizontal",
        legend.text      = element_text(size = 10),
        legend.title     = element_text(size = 10)) +
  labs(title = "Cooling Centers by State",
       x = NULL, y = "Number of facilities")

final_desc <- cowplot::plot_grid(
  cowplot::plot_grid(pA, pB, ncol = 2,
                     rel_widths = c(0.85, 1.15)),
  pC, ncol = 1, rel_heights = c(1.1, 2.0)) +
  theme(plot.background = element_rect(fill = "white",
                                        color = NA))

ggsave(file.path(dir_out, "cdf_gini",
                 "cooling_center_descriptives.png"),
       plot = final_desc, width = 16, height = 24,
       dpi = 400, bg = "white")

