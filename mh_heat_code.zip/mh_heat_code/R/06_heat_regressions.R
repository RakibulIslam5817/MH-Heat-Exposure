

# 05_heat_regressions.R
# County fixed-effects models of heat exposure by housing type
#
# Specification:
#   y_ibc = b1 * MH_i + d * X_ib + a_c + e_ibc
# where y is the heat exposure outcome for building i in block
# group b and county c, MH is a binary indicator, X is a vector
# of block-group socioeconomic controls, a_c is a county fixed
# effect, and standard errors are clustered at county level.
# All models are weighted by the inverse probability sampling
# weights.
#
# OLS for the continuous outcomes (p98 Tmax, p95 Tmax, CDD);
# Poisson for the exceedance day counts.
#
# Inputs:
#   output/regression/analysis_dataset.csv
#
# Outputs:
#   output/regression/reg_mh_sf_dataset.csv
#   output/regression/reg_mh_mf_dataset.csv
#   output/regression/ols_results.csv        
#   output/regression/poisson_results.csv    
#
# Run 00_setup.R first.



analysis_df <- read_csv(
  file.path(dir_out, "regression", "analysis_dataset.csv"),
  col_types = cols(
    UUID        = col_character(),
    Building    = col_character(),
    state_fips  = col_character(),
    county_fips = col_character(),
    CENSUSCODE  = col_character(),
    region      = col_character(),
    BG_GEOID    = col_character(),
    tract_GEOID = col_character(),
    exc_p98     = col_integer(),
    exc_p95     = col_integer(),
    .default    = col_guess()
  )
) |>
  mutate(
    Building = factor(Building, levels = building_levels),
    region   = factor(region,   levels = regions)
  )

cat("Rows:", format(nrow(analysis_df), big.mark = ","), "\n")

########################### Pairwise comparison datasets ###########################
keep_cols <- c(
  "UUID", "Building", "state_fips", "county_fips", "region",
  "weight", "LATITUDE", "LONGITUDE",
  "p98_tmax", "p95_tmax", "exc_p98", "exc_p95", "cdd_18",
  controls
)

make_pair <- function(data, comparison_type) {
  data |>
    select(all_of(keep_cols)) |>
    filter(Building %in% c("MH", comparison_type)) |>
    mutate(
      # The comparison type is the reference category, so the
      # MH coefficient is the contrast of interest
      Building    = factor(Building,
                           levels = c(comparison_type, "MH")),
      county_fips = factor(county_fips),
      region      = factor(region, levels = regions)
    ) |>
    filter(if_all(all_of(controls), ~ !is.na(.x)))
}

reg_mh_sf <- make_pair(analysis_df, "Single Family")
reg_mh_mf <- make_pair(analysis_df, "Multi-Family")

cat("MH vs SF:", format(nrow(reg_mh_sf), big.mark = ","), "\n")
cat("MH vs MF:", format(nrow(reg_mh_mf), big.mark = ","), "\n")

write.csv(reg_mh_sf,
  file.path(dir_out, "regression", "reg_mh_sf_dataset.csv"),
  row.names = FALSE)
write.csv(reg_mh_mf,
  file.path(dir_out, "regression", "reg_mh_mf_dataset.csv"),
  row.names = FALSE)

########################### Outcomes ###########################
ols_outcomes <- list(
  list(var = "p98_tmax", label = "p98 Tmax (C)"),
  list(var = "p95_tmax", label = "p95 Tmax (C)"),
  list(var = "cdd_18",   label = "CDD (>18.3C)")
)

pois_outcomes <- list(
  list(var = "exc_p98", label = "Exc Days (p98)"),
  list(var = "exc_p95", label = "Exc Days (p95)")
)

all_levels <- c("National", regions)

########################### Result extractors ###########################
extract_ols <- function(model, outcome_label, region_label,
                         comparison_label) {
  fs <- fitstat(model, type = c("r2", "wr2", "ar2", "rmse", "n"))

  tidy(model, conf.int = TRUE) |>
    filter(str_detect(term, "BuildingMH")) |>
    mutate(
      comparison = comparison_label,
      region     = region_label,
      outcome    = outcome_label,
      sig        = sig_stars(p.value),
      n_obs      = as.integer(fs$n),
      r2_within  = round(as.numeric(fs$wr2),  6),
      r2_overall = round(as.numeric(fs$r2),   6),
      r2_adj     = round(as.numeric(fs$ar2),  6),
      rmse       = round(as.numeric(fs$rmse), 6)
    ) |>
    select(comparison, region, outcome, estimate, std.error,
           statistic, p.value, sig, conf.low, conf.high,
           n_obs, r2_within, r2_overall, r2_adj, rmse) |>
    mutate(across(where(is.numeric) & !any_of("p.value"),
                  ~ round(.x, 4)))
}

# Poisson coefficients are reported as incidence rate ratios,
# IRR = exp(beta). Standard errors remain on the log scale.
extract_irr <- function(model, outcome_label, region_label,
                         comparison_label) {
  tidy(model, conf.int = TRUE) |>
    filter(str_detect(term, "BuildingMH")) |>
    mutate(
      comparison = comparison_label,
      region     = region_label,
      outcome    = outcome_label,
      irr        = round(exp(estimate),  4),
      irr_low    = round(exp(conf.low),  4),
      irr_high   = round(exp(conf.high), 4),
      pct_diff   = round((exp(estimate) - 1) * 100, 2),
      sig        = sig_stars(p.value)
    ) |>
    select(comparison, region, outcome, estimate, std.error,
           statistic, p.value, sig, conf.low, conf.high,
           irr, irr_low, irr_high, pct_diff) |>
    mutate(across(where(is.numeric) & !any_of("p.value"),
                  ~ round(.x, 4)))
}

########################### Model fitting ###########################
fit_model <- function(data, ov, r, comp, estimator) {
  df <- if (r == "National") data else filter(data, region == r)
  if (nrow(df) == 0) return(NULL)

  fml <- as.formula(paste0(
    ov$var, " ~ Building + ", control_formula, " | county_fips"))

  tryCatch({
    m <- if (estimator == "ols") {
      feols(fml, data = df, weights = ~ weight,
            cluster = ~ county_fips, fixef.rm = "singleton")
    } else {
      fepois(fml, data = df, weights = ~ weight,
             cluster = ~ county_fips, fixef.rm = "singleton")
    }
    if (estimator == "ols") {
      extract_ols(m, ov$label, r, comp)
    } else {
      extract_irr(m, ov$label, r, comp)
    }
  }, error = function(e) {
    cat("Failed:", r, ov$var, "|", conditionMessage(e), "\n")
    NULL
  })
}

cat("\nFitting OLS models...\n")

ols_results <- bind_rows(
  map_dfr(ols_outcomes, function(ov)
    map_dfr(all_levels, ~ fit_model(reg_mh_sf, ov, .x,
                                    "MH vs Single Family", "ols"))),
  map_dfr(ols_outcomes, function(ov)
    map_dfr(all_levels, ~ fit_model(reg_mh_mf, ov, .x,
                                    "MH vs Multi-Family", "ols")))
)

cat("Fitting Poisson models...\n")

pois_results <- bind_rows(
  map_dfr(pois_outcomes, function(ov)
    map_dfr(all_levels, ~ fit_model(reg_mh_sf, ov, .x,
                                    "MH vs Single Family", "pois"))),
  map_dfr(pois_outcomes, function(ov)
    map_dfr(all_levels, ~ fit_model(reg_mh_mf, ov, .x,
                                    "MH vs Multi-Family", "pois")))
)

cat("\nOLS results (Table 3):\n")
ols_results |>
  arrange(comparison, outcome, region) |>
  print(n = 100, width = Inf)

cat("\nPoisson results (Table 4):\n")
pois_results |>
  arrange(comparison, outcome, region) |>
  print(n = 60, width = Inf)

write.csv(ols_results,
  file.path(dir_out, "regression", "ols_results.csv"),
  row.names = FALSE)
write.csv(pois_results,
  file.path(dir_out, "regression", "poisson_results.csv"),
  row.names = FALSE)


