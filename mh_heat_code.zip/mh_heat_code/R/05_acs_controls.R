

# 04_acs_controls.R
# Block group assignment, ACS controls, urban/rural indicator
#
# Inputs:
#   output/heat_measures/heat_measures_all.csv
#   American Community Survey 5-year estimates (downloaded via
#     the tidycensus API; a Census API key is required, see
#     00_setup.R)
#   2020 Census blocks within urban areas (downloaded via tigris)
#
# Outputs:
#   output/regression/analysis_dataset.csv
#
# Run 00_setup.R first.


heat_measures <- read_csv(
  file.path(dir_out, "heat_measures", "heat_measures_all.csv"),
  col_types = cols(
    UUID        = col_character(),
    state_fips  = col_character(),
    county_fips = col_character(),
    CENSUSCODE  = col_character(),
    .default    = col_guess()
  )
)

states_needed <- sort(unique(heat_measures$state_fips))
cat("States:", length(states_needed), "\n")

########################### Assign each building to a block group ###########################
# The structure inventory carries a tract-level code, but the
# ACS controls are specified at block group level, so building
# points are spatially joined to 2024 block group boundaries.

cat("\nDownloading block group boundaries...\n")

bg_boundaries <- map_dfr(states_needed, function(s) {
  tryCatch(
    block_groups(state = s, year = 2024, cb = TRUE) |>
      select(GEOID, ALAND) |>
      st_transform(crs = crs_wgs84),
    error = function(e) {
      cat("Failed:", s, "\n"); NULL
    })
})

cat("Block groups:", format(nrow(bg_boundaries), big.mark = ","), "\n")

heat_sf <- heat_measures |>
  select(-any_of(c("BG_GEOID", "ALAND", "GEOID", "tract_GEOID"))) |>
  filter(!is.na(LATITUDE), !is.na(LONGITUDE)) |>
  st_as_sf(coords = c("LONGITUDE", "LATITUDE"),
           crs = crs_wgs84, remove = FALSE)

cat("\nSpatially joining buildings to block groups...\n")
t0 <- Sys.time()

bg_join <- map_dfr(states_needed, function(s) {

  bldgs <- heat_sf       |> filter(state_fips == s)
  bgs   <- bg_boundaries |> filter(substr(GEOID, 1, 2) == s)

  if (nrow(bldgs) == 0 || nrow(bgs) == 0) {
    cat("  ", s, "skipped\n"); return(NULL)
  }

  joined <- st_join(bldgs, bgs |> select(GEOID, ALAND),
                     join = st_within, left = TRUE) |>
    st_drop_geometry() |>
    rename(BG_GEOID = GEOID) |>
    select(UUID, BG_GEOID, ALAND)

  cat("  ", s, "|", format(nrow(joined), big.mark = ","),
      "joined | NA:", sum(is.na(joined$BG_GEOID)), "\n")

  joined
})

cat("Done in:",
    round(difftime(Sys.time(), t0, units = "mins"), 1), "mins\n")
cat("Match rate:",
    round(mean(!is.na(bg_join$BG_GEOID)) * 100, 1), "%\n")

heat_measures <- heat_measures |>
  select(-any_of(c("tract_GEOID", "BG_GEOID", "ALAND"))) |>
  left_join(bg_join, by = "UUID") |>
  mutate(tract_GEOID = substr(BG_GEOID, 1, 11))

stopifnot(
  all(nchar(na.omit(heat_measures$BG_GEOID))    == 12),
  all(nchar(na.omit(heat_measures$tract_GEOID)) == 11)
)

########################### ACS controls ###########################
# Block group level: population, race and ethnicity, income,
#   employment, tenure, housing age
# Tract level: nativity and poverty, which are not published at
#   block group level

cat("\nDownloading ACS block group estimates...\n")

acs_bg_raw <- map_dfr(states_needed, function(s) {
  tryCatch(
    get_acs(
      geography = "block group", state = s, year = 2024,
      survey = "acs5", output = "wide", geometry = FALSE,
      variables = c(
        total_pop        = "B01003_001",
        nh_white         = "B03002_003",
        hispanic         = "B03002_012",
        total_race       = "B03002_001",
        median_hh_income = "B19013_001",
        unemployed       = "B23025_005",
        labor_force      = "B23025_002",
        owner_occupied   = "B25003_002",
        total_housing    = "B25003_001",
        median_yr_built  = "B25035_001"
      )),
    error = function(e) { cat("Failed:", s, "\n"); NULL })
})

cat("Downloading ACS tract estimates...\n")

acs_tract_raw <- map_dfr(states_needed, function(s) {
  tryCatch(
    get_acs(
      geography = "tract", state = s, year = 2024,
      survey = "acs5", output = "wide", geometry = FALSE,
      variables = c(
        foreign_born   = "B05002_013",
        total_nativity = "B05002_001",
        below_poverty  = "B17001_002",
        total_poverty  = "B17001_001"
      )),
    error = function(e) { cat("Failed:", s, "\n"); NULL })
})

acs_bg_clean <- acs_bg_raw |>
  transmute(
    BG_GEOID         = GEOID,
    total_pop        = total_popE,
    share_nh_white   = nh_whiteE       / total_raceE,
    share_hispanic   = hispanicE       / total_raceE,
    median_hh_income = median_hh_incomeE,
    unemp_rate       = unemployedE     / labor_forceE,
    homeown_rate     = owner_occupiedE / total_housingE,
    median_yr_built  = median_yr_builtE,
    across(where(is.numeric),
           ~ ifelse(is.infinite(.x) | is.nan(.x), NA_real_, .x))
  )

acs_tract_clean <- acs_tract_raw |>
  transmute(
    tract_GEOID     = GEOID,
    share_immigrant = foreign_bornE  / total_nativityE,
    poverty_rate    = below_povertyE / total_povertyE,
    across(where(is.numeric),
           ~ ifelse(is.infinite(.x) | is.nan(.x), NA_real_, .x))
  )

########################### Urban / rural block group indicator ###########################

# A block group is classified as urban if it contains at least
# one census block within a 2020 Census-defined urban area, and
# rural otherwise.
#
# Source: US Census Bureau, 2020 Census Urban Area Blocks file
#   https://www2.census.gov/geo/docs/reference/ua/2020_UA_BLOCKS.txt
#   Pipe-delimited, 4,107,577 rows, 281.5 MB.
#   Field layout: 2020_UA_BLOCKS_Descriptions.txt in the same
#   directory.
#
# The file lists only blocks that fall within an urban area, so
# no filtering on 2020_UACE is required; every record in it is
# by definition urban.
#
# The download is large and the default R timeout of 60 seconds
# is not sufficient, so the timeout is raised before fetching.
# The file is cached locally and re-downloaded only if absent.

ua_blocks_url  <- paste0(
  "https://www2.census.gov/geo/docs/reference/ua/",
  "2020_UA_BLOCKS.txt"
)
ua_blocks_path <- file.path(dir_data, "2020_UA_BLOCKS.txt")

if (!file.exists(ua_blocks_path)) {
  cat("Downloading 2020 Census Urban Area Blocks file",
      "(281.5 MB)...\n")
  old_timeout <- getOption("timeout")
  options(timeout = 1800)
  download.file(ua_blocks_url, ua_blocks_path,
                mode = "wb", method = "libcurl")
  options(timeout = old_timeout)
}

cat("Reading urban area blocks...\n")

ua_blocks <- read_delim(
  ua_blocks_path,
  delim     = "|",
  col_types = cols(
    STATE          = col_character(),
    COUNTY         = col_character(),
    TRACT          = col_character(),
    BLOCK          = col_character(),
    GEOID          = col_character(),
    AREALAND       = col_double(),
    `2020_HOU`     = col_double(),
    `2020_POP`     = col_double(),
    `2020_UACE`    = col_character(),
    `2020_UA_NAME` = col_character()
  )
)

# Guard against a truncated download: the published file has
# 4,107,577 blocks across 2,638 urban areas
stopifnot(
  nrow(ua_blocks) == 4107577,
  !any(is.na(ua_blocks$`2020_UACE`))
)

cat("Urban blocks:",
    format(nrow(ua_blocks), big.mark = ","), "\n")
cat("Urban areas: ",
    format(n_distinct(ua_blocks$`2020_UACE`),
           big.mark = ","), "\n")

# The block GEOID is 15 digits (state, county, tract, block);
# its first 12 digits give the block group identifier.
urban_bg_geoids <- ua_blocks |>
  mutate(BG_GEOID = substr(GEOID, 1, 12)) |>
  distinct(BG_GEOID) |>
  mutate(is_urban_bg = 1L)

stopifnot(nrow(urban_bg_geoids) == 200568)

cat("Urban block groups:",
    format(nrow(urban_bg_geoids), big.mark = ","), "\n")

########################### Assemble the analysis dataset ###########################
analysis_df <- heat_measures |>
  left_join(acs_bg_clean,    by = "BG_GEOID")  |>
  left_join(acs_tract_clean, by = "tract_GEOID") |>
  left_join(urban_bg_geoids, by = "BG_GEOID")  |>
  mutate(
    pop_density = total_pop / (ALAND / 1e6),
    is_urban_bg = replace(is_urban_bg, is.na(is_urban_bg), 0L),
    across(where(is.numeric),
           ~ ifelse(is.infinite(.x) | is.nan(.x), NA_real_, .x))
  ) |>
  filter(if_all(all_of(controls), ~ !is.na(.x)))

cat("\nAnalysis dataset rows:",
    format(nrow(analysis_df), big.mark = ","), "\n")
cat("Drop rate:",
    round((nrow(heat_measures) - nrow(analysis_df)) /
            nrow(heat_measures) * 100, 1), "%\n")

print(table(analysis_df$Building))
print(table(analysis_df$region))

cat("\nUrban share by building type:\n")
analysis_df |>
  group_by(Building) |>
  summarise(n = n(),
            pct_urban = round(mean(is_urban_bg) * 100, 1),
            .groups = "drop") |>
  print()

# Collinearity check between the two density measures
ct <- cor.test(analysis_df$pop_density, analysis_df$is_urban_bg)
cat("\nCorrelation pop_density vs is_urban_bg: r =",
    round(ct$estimate, 4), "\n")

write.csv(analysis_df,
  file.path(dir_out, "regression", "analysis_dataset.csv"),
  row.names = FALSE)

