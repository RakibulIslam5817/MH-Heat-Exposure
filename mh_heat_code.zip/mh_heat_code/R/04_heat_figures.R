

# 03_heat_figures.R
# CDF panel figures and threshold bar plots
#
# Inputs:
#   output/heat_measures/heat_measures_all.csv
#   output/heat_measures/threshold_exposure_stats.csv
#   output/heat_measures/exceedance_cdd_stats.csv
#
# Outputs (output/maps/):
#   CDF_Tmax_Combined.png       
#   CDF_ExcDays_Combined.png    
#   CDF_CDD_3col.png            
#   Barplot_Tmax_Combined.png   
#   exceedance_days_barplot.png 
#   cdd_barplot.png             
#
# Run 00_setup.R and 02_cdf_gini.R first; this script reuses
# cdf_data and gini_labs from 02_cdf_gini.R.


dir_maps <- file.path(dir_out, "maps")
dir_heat <- file.path(dir_out, "heat_measures")

save_fig <- function(plot, path, width, height, dpi = 400) {
  ggsave(path, plot = plot, width = width, height = height,
         dpi = dpi, bg = "white")
  cat("Saved:", basename(path), "\n")
}

########################### Single CDF panel ###########################
make_panel <- function(geo, cdf_df, gini_df, x_label) {
  plot_data <- cdf_df  |> filter(geography == geo)
  gini_val  <- gini_df |> filter(geography == geo)
  x_min <- min(cdf_df$x, na.rm = TRUE)
  x_max <- max(cdf_df$x, na.rm = TRUE)

  ggplot(plot_data, aes(x = x, y = cdf, color = Building)) +
    geom_step(linewidth = 0.75) +
    scale_color_manual(name = "Building type:",
                       values = building_colors) +
    scale_y_continuous(breaks = seq(0, 1, 0.25), limits = c(0, 1),
                       expand = expansion(mult = c(0.01, 0.01))) +
    scale_x_continuous(limits = c(x_min, x_max),
                       expand = expansion(mult = c(0.03, 0.03))) +
    annotate("text", x = Inf, y = 0.07,
             label = paste0("Gini = ", gini_val$gini),
             hjust = 1.15, vjust = 0, size = 2.8,
             color = "black") +
    labs(title = geo, x = x_label, y = NULL) +
    theme_classic(base_size = 9) +
    theme(
      plot.title      = element_text(size = 9, face = "bold",
                                      hjust = 0.5,
                                      margin = margin(b = 4)),
      axis.title.x    = element_text(size = 8,
                                      margin = margin(t = 4)),
      axis.text       = element_text(size = 7, color = "black"),
      axis.ticks      = element_line(color = "black",
                                      linewidth = 0.3),
      axis.line       = element_line(color = "black",
                                      linewidth = 0.3),
      legend.position = "none",
      plot.background = element_rect(fill = "white", color = NA),
      plot.margin     = margin(4, 6, 4, 6)
    )
}

########################### Shared legend and panel labels ###########################
get_legend_row <- function() {
  dummy <- ggplot(
    data.frame(
      Building = factor(building_levels, levels = building_levels),
      x = 1, y = 1),
    aes(x = x, y = y, color = Building)) +
    geom_line(linewidth = 1.2) +
    scale_color_manual(name = "Building type:",
                       values = building_colors) +
    theme_void() +
    theme(
      legend.position  = "bottom",
      legend.direction = "horizontal",
      legend.title     = element_text(size = 10),
      legend.text      = element_text(size = 10),
      legend.key.width = unit(1.2, "cm")
    )
  cowplot::get_legend(dummy)
}

make_strip_label <- function(label) {
  cowplot::ggdraw() +
    cowplot::draw_label(label, fontface = "bold", x = 0.01,
                        hjust = 0, size = 11, color = "black")
}

########################### Two-measure combined CDF figure ###########################
make_combined_figure <- function(measure_a, measure_b,
                                  xlabel_a, xlabel_b,
                                  out_path, ncols = 4) {

  panels_a <- map(geos, ~ make_panel(
    geo = .x, cdf_df = cdf_data[[measure_a]],
    gini_df = gini_labs[[measure_a]], x_label = xlabel_a))
  panels_b <- map(geos, ~ make_panel(
    geo = .x, cdf_df = cdf_data[[measure_b]],
    gini_df = gini_labs[[measure_b]], x_label = xlabel_b))

  nrows  <- ceiling(length(geos) / ncols)
  grid_a <- cowplot::plot_grid(plotlist = panels_a, ncol = ncols,
                                nrow = nrows, align = "hv")
  grid_b <- cowplot::plot_grid(plotlist = panels_b, ncol = ncols,
                                nrow = nrows, align = "hv")

  final <- cowplot::plot_grid(
    make_strip_label("a)"), grid_a,
    cowplot::ggdraw(),
    make_strip_label("b)"), grid_b,
    get_legend_row(),
    ncol        = 1,
    rel_heights = c(0.04, 1, 0.035, 0.04, 1, 0.07)
  )

  save_fig(final, out_path, width = 13, height = 10.5, dpi = 500)
}

########################### Standalone CDD CDF figure ###########################
make_cdd_figure <- function(out_path) {
  panels_cdd <- map(geos, ~ make_panel(
    geo = .x, cdf_df = cdf_data[["cdd_18"]],
    gini_df = gini_labs[["cdd_18"]],
    x_label = "Cooling Degree Days (>18.3°C)"))

  grid_cdd <- cowplot::plot_grid(
    plotlist = panels_cdd, ncol = 3,
    nrow = ceiling(length(geos) / 3), align = "hv")

  final <- cowplot::plot_grid(grid_cdd, get_legend_row(),
                               ncol = 1, rel_heights = c(1, 0.05))

  save_fig(final, out_path, width = 10, height = 11, dpi = 500)
}


make_combined_figure(
  measure_a = "p95_tmax", measure_b = "p98_tmax",
  xlabel_a  = "p95 Tmax (°C)",
  xlabel_b  = "p98 Tmax (°C)",
  out_path  = file.path(dir_maps, "CDF_Tmax_Combined.png"))

make_combined_figure(
  measure_a = "exc_p95", measure_b = "exc_p98",
  xlabel_a  = "Exceedance Days (Regional p95 threshold)",
  xlabel_b  = "Exceedance Days (Regional p98 threshold)",
  out_path  = file.path(dir_maps, "CDF_ExcDays_Combined.png"))

make_cdd_figure(file.path(dir_maps, "CDF_CDD_3col.png"))

########################### Bar plots ###########################
all_thresh <- read_csv(
  file.path(dir_heat, "threshold_exposure_stats.csv"),
  col_types = cols(.default = col_guess())) |>
  mutate(
    Building        = factor(Building,  levels = building_levels),
    geography       = factor(geography, levels = geos),
    threshold_label = factor(
      paste0(threshold, "°C"),
      levels = c("32°C", "35°C", "40°C"))
  )

all_counts <- read_csv(
  file.path(dir_heat, "exceedance_cdd_stats.csv"),
  col_types = cols(.default = col_guess())) |>
  mutate(
    Building  = factor(Building,  levels = building_levels),
    geography = factor(geography, levels = geos)
  )

bar_theme <- theme_classic(base_size = 10) +
  theme(
    legend.position  = "bottom",
    legend.direction = "horizontal",
    legend.title     = element_text(size = 11),
    legend.text      = element_text(size = 11),
    strip.background = element_blank(),
    strip.text       = element_text(size = 10, face = "bold"),
    axis.text        = element_text(size = 9, color = "black"),
    axis.title.y     = element_text(size = 10),
    panel.spacing    = unit(1.2, "lines"),
    plot.background  = element_rect(fill = "white", color = NA)
  )

make_tmax_bar <- function(measure_name) {
  all_thresh |>
    filter(measure == measure_name) |>
    ggplot(aes(x = threshold_label, y = pct_above,
               fill = Building)) +
    geom_col(position = position_dodge(0.72), width = 0.7) +
    scale_fill_manual(name = "Building type:",
                      values = building_colors) +
    scale_y_continuous(limits = c(0, 100),
                       expand = expansion(mult = c(0, 0.05))) +
    facet_wrap(~ geography, ncol = 4) +
    labs(x = "Temperature Threshold",
         y = "% Buildings Exposed") +
    bar_theme +
    theme(legend.position = "none")
}

make_bar_combined <- function(bar_a, bar_b, out_path) {
  final <- cowplot::plot_grid(
    make_strip_label("a)"), bar_a,
    cowplot::ggdraw(),
    make_strip_label("b)"), bar_b,
    get_legend_row(),
    ncol        = 1,
    rel_heights = c(0.04, 1, 0.03, 0.04, 1, 0.07)
  )
  save_fig(final, out_path, width = 14, height = 12, dpi = 500)
}


make_bar_combined(
  bar_a    = make_tmax_bar("p95_tmax"),
  bar_b    = make_tmax_bar("p98_tmax"),
  out_path = file.path(dir_maps, "Barplot_Tmax_Combined.png"))

# Exceedance days
p_exc <- all_counts |>
  filter(measure %in% c("exc_p98", "exc_p95")) |>
  mutate(measure = recode(measure,
                          exc_p98 = "Exc Days (p98)",
                          exc_p95 = "Exc Days (p95)")) |>
  ggplot(aes(x = measure, y = mean_val, fill = Building)) +
  geom_col(position = position_dodge(0.72), width = 0.7) +
  scale_fill_manual(name = "Building type:",
                    values = building_colors) +
  scale_y_continuous(limits = c(0, 16), breaks = seq(0, 16, 4),
                     expand = expansion(mult = c(0, 0))) +
  facet_wrap(~ geography, ncol = 4) +
  labs(x = NULL, y = "Mean Days") +
  bar_theme +
  theme(axis.text.x = element_text(angle = 10, hjust = 1))

save_fig(p_exc, file.path(dir_maps, "exceedance_days_barplot.png"),
         width = 14, height = 10)

# Cooling degree days
p_cdd <- all_counts |>
  filter(measure == "cdd_18") |>
  mutate(measure = recode(measure,
                          cdd_18 = "CDD (>18.3°C)")) |>
  ggplot(aes(x = measure, y = mean_val, fill = Building)) +
  geom_col(position = position_dodge(0.62), width = 0.6) +
  scale_fill_manual(name = "Building type:",
                    values = building_colors) +
  scale_y_continuous(limits = c(0, 3000), breaks = seq(0, 3000, 500),
                     expand = expansion(mult = c(0, 0))) +
  facet_wrap(~ geography, ncol = 4) +
  labs(x = NULL, y = "Mean Cooling Degree Days (°C-days)") +
  bar_theme

save_fig(p_cdd, file.path(dir_maps, "cdd_barplot.png"),
         width = 12, height = 10)

