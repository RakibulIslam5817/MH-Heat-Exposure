

# 02_cdf_gini.R
# Weighted CDFs, Gini coefficients, and threshold statistics
#
# Inputs:
#   output/heat_measures/heat_measures_all.csv
#
# Outputs:
#   output/cdf_gini/gini_table.csv
#   output/heat_measures/threshold_exposure_stats.csv
#   output/heat_measures/exceedance_cdd_stats.csv
#
#
# Run 00_setup.R first.

heat_measures <- read_csv(
  file.path(dir_out, "heat_measures", "heat_measures_all.csv"),
  col_types = cols(
    UUID        = col_character(),
    Building    = col_character(),
    state_fips  = col_character(),
    county_fips = col_character(),
    CENSUSCODE  = col_character(),
    region      = col_character(),
    weight      = col_double(),
    p98_tmax    = col_double(),
    p95_tmax    = col_double(),
    exc_p98     = col_double(),
    exc_p95     = col_double(),
    cdd_18      = col_double(),
    .default    = col_guess()
  )
) |>
  mutate(
    Building = factor(Building, levels = building_levels),
    region   = factor(region,   levels = regions)
  )

cat("Loaded:", format(nrow(heat_measures), big.mark = ","),
    "buildings\n\n")

########################### Weighted CDFs ###########################
build_cdf_df <- function(data, measure) {
  data |>
    group_by(Building) |>
    group_modify(~ weighted_cdf(.x[[measure]], .x$weight)) |>
    ungroup() |>
    mutate(measure = measure)
}

build_geo_cdf <- function(var) {
  nat <- build_cdf_df(heat_measures, var) |>
    mutate(geography = "National")

  reg <- heat_measures |>
    filter(region %in% regions) |>
    group_by(region) |>
    group_modify(function(d, k) build_cdf_df(d, var)) |>
    ungroup() |>
    rename(geography = region)

  bind_rows(nat, reg) |>
    mutate(
      geography = factor(geography, levels = geos),
      Building  = factor(Building,  levels = building_levels)
    )
}

cat("Building CDF data for all measures...\n")
cdf_data        <- map(all_measures, build_geo_cdf)
names(cdf_data) <- all_measures

########################### Weighted Gini coefficients ###########################
cat("Computing Gini coefficients...\n")

gini_table_all <- map_dfr(geos, function(geo) {
  geo_data <- if (geo == "National") {
    heat_measures
  } else {
    heat_measures |> filter(region == geo)
  }
  map_dfr(all_measures, function(v) {
    compute_group_gini(geo_data, v) |> mutate(geography = geo)
  })
})

gini_wide <- gini_table_all |>
  mutate(measure = recode(measure, !!!measure_labels)) |>
  pivot_wider(names_from = measure, values_from = gini) |>
  mutate(
    geography = factor(geography, levels = geos),
    Group     = factor(Group,
                       levels = c("All buildings", building_levels))
  ) |>
  arrange(geography, Group)

print(gini_wide, n = 40)

write.csv(gini_wide,
  file.path(dir_out, "cdf_gini", "gini_table.csv"),
  row.names = FALSE)

# Gini labels for the CDF panel annotations
gini_labs <- map(all_measures, function(var) {
  gini_table_all |>
    filter(measure == var, Group == "All buildings") |>
    mutate(geography = factor(geography, levels = geos),
           gini      = round(gini, 2)) |>
    select(geography, gini)
})
names(gini_labs) <- all_measures

########################### Threshold exposure statistics ###########################
# Share of buildings whose percentile Tmax value exceeds 32, 35
# and 40 degrees Celsius.

thresholds <- c(32, 35, 40)

compute_threshold_stats <- function(data, geo_label) {
  map_dfr(thresholds, function(thr) {
    map_dfr(c("p98_tmax", "p95_tmax"), function(measure) {
      data |>
        group_by(Building) |>
        summarise(
          geography = geo_label,
          threshold = thr,
          measure   = measure,
          pct_above = pct_above_thresh(.data[[measure]],
                                        weight, thr),
          mean_val  = wmean(.data[[measure]], weight),
          .groups   = "drop"
        )
    })
  })
}

compute_count_stats <- function(data, geo_label) {
  map_dfr(c("exc_p98", "exc_p95", "cdd_18"), function(measure) {
    data |>
      group_by(Building) |>
      summarise(
        geography  = geo_label,
        measure    = measure,
        mean_val   = wmean(.data[[measure]], weight),
        median_val = round(median(.data[[measure]],
                                  na.rm = TRUE), 2),
        pct_zero   = round(weighted.mean(.data[[measure]] == 0,
                                          weight,
                                          na.rm = TRUE) * 100, 1),
        p75_val    = round(quantile(.data[[measure]],
                                     probs = 0.75,
                                     na.rm = TRUE), 2),
        p90_val    = round(quantile(.data[[measure]],
                                     probs = 0.90,
                                     na.rm = TRUE), 2),
        .groups    = "drop"
      )
  })
}

cat("\nComputing threshold statistics...\n")

all_thresh <- bind_rows(
  compute_threshold_stats(heat_measures, "National"),
  map_dfr(regions, function(r) {
    compute_threshold_stats(
      heat_measures |> filter(region == r), r)
  })
) |>
  mutate(
    Building        = factor(Building, levels = building_levels),
    geography       = factor(geography, levels = geos),
    threshold_label = factor(paste0(threshold, "°C"),
                             levels = paste0(thresholds, "°C"))
  )

all_counts <- bind_rows(
  compute_count_stats(heat_measures, "National"),
  map_dfr(regions, function(r) {
    compute_count_stats(
      heat_measures |> filter(region == r), r)
  })
) |>
  mutate(
    Building  = factor(Building, levels = building_levels),
    geography = factor(geography, levels = geos)
  )

cat("\nShare of buildings with p95 Tmax at or above threshold:\n")
all_thresh |>
  filter(measure == "p95_tmax") |>
  select(geography, threshold, Building, pct_above) |>
  pivot_wider(names_from = Building, values_from = pct_above) |>
  arrange(geography, threshold) |>
  print(n = 50)

cat("\nNational cooling degree days:\n")
all_counts |>
  filter(geography == "National", measure == "cdd_18") |>
  select(Building, mean_val, median_val, p75_val, p90_val) |>
  print()

write.csv(all_thresh,
  file.path(dir_out, "heat_measures",
            "threshold_exposure_stats.csv"),
  row.names = FALSE)

write.csv(all_counts,
  file.path(dir_out, "heat_measures",
            "exceedance_cdd_stats.csv"),
  row.names = FALSE)

