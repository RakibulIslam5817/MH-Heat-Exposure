

# 08_maps.R
# Study area and sample distribution maps
#
# Inputs:
#   output/regression/analysis_dataset.csv
#   cooling_all (from 06_cooling_centers.R)
#   American Community Survey table B25024 (via tidycensus)
#
# Outputs (output/maps/):
#   mh_share_map.png             
#   cooling_centers_map.png      
#   sample_distribution.png     
#   acs_mh_proportion_2024.csv
#
# Run 00_setup.R first. The cooling center map requires
# cooling_all from 06_cooling_centers.R.


dir_maps <- file.path(dir_out, "maps")

########################### State and region boundaries ###########################
states_sf <- states(cb = TRUE, year = 2022) |>
  filter(!STUSPS %in% c("AK", "HI", "PR", "VI", "GU",
                        "MP", "AS", "DC")) |>
  st_transform(crs = crs_albers) |>
  mutate(region = assign_region(GEOID))

unassigned <- states_sf |> filter(is.na(region)) |> pull(STUSPS)
if (length(unassigned) > 0) {
  cat("Unassigned states:",
      paste(unassigned, collapse = ", "), "\n")
}

# Dissolve states into the seven analysis regions
regions_sf <- states_sf |>
  filter(!is.na(region)) |>
  group_by(region) |>
  summarise(.groups = "drop") |>
  st_make_valid()

cat("Region polygons:", nrow(regions_sf), "\n")

# Region label positions, with manual offsets where the
# automatic placement overlaps dense data
region_labels <- regions_sf |>
  st_point_on_surface() |>
  mutate(lon = st_coordinates(geometry)[, 1],
         lat = st_coordinates(geometry)[, 2]) |>
  st_drop_geometry() |>
  mutate(lat = case_when(
    region == "Great Lakes" ~ lat - 150000,
    TRUE                    ~ lat
  ))

########################### cooling center locations ###########################
if (exists("cooling_all")) {

  covered_fips <- cooling_all |>
    st_drop_geometry() |>
    distinct(state_fips) |>
    pull(state_fips)

  states_sf <- states_sf |>
    mutate(covered = ifelse(GEOID %in% covered_fips,
                            "covered", "missing"))

  # Keep only points that fall inside the contiguous United
  # States, and drop duplicate facility records
  conus_buffered <- states_sf |> st_union() |> st_buffer(5000)

  cooling_pts <- cooling_all |>
    filter(!st_is_empty(geom)) |>
    mutate(inside = st_within(geom, conus_buffered,
                              sparse = FALSE)[, 1]) |>
    filter(inside) |>
    distinct(facility_name, location, state_abbrev,
             .keep_all = TRUE) |>
    select(-inside)

  cat("Mapping", format(nrow(cooling_pts), big.mark = ","),
      "cooling centers across", length(covered_fips),
      "states\n")

  p_cooling_map <- ggplot() +
    geom_sf(data = states_sf |> filter(covered == "covered"),
            fill = "#E8F1F8", color = "white", linewidth = 0.3) +
    geom_sf(data = states_sf |> filter(covered == "missing"),
            aes(fill = "No cooling center data"),
            color = "white", linewidth = 0.3) +
    scale_fill_manual(
      name   = NULL,
      values = c("No cooling center data" = "#E0E0E0")) +
    geom_sf(data = regions_sf, fill = NA, color = "grey25",
            linewidth = 0.7) +
    geom_sf(data = cooling_pts, aes(color = "Cooling center"),
            size = 0.45, alpha = 0.45, shape = 16) +
    scale_color_manual(name = NULL,
                       values = c("Cooling center" = "#C0392B")) +
    geom_text(data = region_labels,
              aes(x = lon, y = lat, label = region),
              size = 3.2, fontface = "bold", color = "grey15") +
    guides(
      fill  = guide_legend(order = 1,
                           override.aes = list(alpha = 1)),
      color = guide_legend(order = 2,
                           override.aes = list(size = 2.2,
                                               alpha = 1))) +
    theme_void(base_size = 12) +
    theme(
      legend.position = "bottom",
      legend.box      = "horizontal",
      legend.text     = element_text(size = 10),
      legend.key.size = unit(0.5, "cm"),
      plot.margin     = margin(10, 10, 10, 10),
      plot.background = element_rect(fill = "white",
                                      color = NA))

  ggsave(file.path(dir_maps, "cooling_centers_map.png"),
         plot = p_cooling_map, width = 11, height = 7,
         dpi = 400, bg = "white")

} else {
  cat("cooling_all not found; run 06_cooling_centers.R")
}

########################### Sample distribution map ###########################
analysis_df <- read_csv(
  file.path(dir_out, "regression", "analysis_dataset.csv"),
  col_types = cols(
    UUID       = col_character(),
    Building   = col_character(),
    state_fips = col_character(),
    .default   = col_guess()))

sample_sf <- analysis_df |>
  st_as_sf(coords = c("LONGITUDE", "LATITUDE"),
           crs = crs_wgs84) |>
  st_transform(crs = crs_albers) |>
  mutate(Building = factor(
    Building,
    levels = building_levels,
    labels = c("(a) Manufactured Housing",
               "(b) Single-Family",
               "(c) Multi-Family")))

sample_colors <- setNames(unname(building_colors),
                          levels(sample_sf$Building))

p_sample <- ggplot() +
  geom_sf(data = states_sf, fill = "grey96", color = "white",
          linewidth = 0.25) +
  geom_sf(data = sample_sf, aes(color = Building),
          size = 0.005, alpha = 0.18, shape = 16) +
  scale_color_manual(values = sample_colors, guide = "none") +
  facet_wrap(~ Building, ncol = 2) +
  theme_void(base_size = 12) +
  theme(
    strip.text      = element_text(size = 12, face = "bold",
                                    margin = margin(b = 6)),
    panel.spacing   = unit(0.8, "lines"),
    plot.background = element_rect(fill = "white", color = NA),
    plot.margin     = margin(10, 10, 10, 10))

ggsave(file.path(dir_maps, "sample_distribution.png"),
       plot = p_sample, width = 11, height = 8,
       dpi = 400, bg = "white")


########################### Manufactured housing share by state ###########################
# ACS table B25024, units in structure. Variable _001 is total
# occupied units and _010 is mobile homes.

cat("\nDownloading ACS manufactured housing shares...\n")

mh_acs <- get_acs(
  geography = "state",
  variables = c(total_occupied = "B25024_001",
                mobile_home    = "B25024_010"),
  year      = 2024,
  survey    = "acs5",
  output    = "wide") |>
  filter(!GEOID %in% c("60", "66", "69", "72", "78")) |>
  mutate(mh_pct = round(100 * mobile_homeE / total_occupiedE, 2)) |>
  select(GEOID, NAME,
         total_occupied = total_occupiedE,
         total_mh       = mobile_homeE,
         mh_pct) |>
  arrange(desc(mh_pct))

print(mh_acs, n = 51)

mh_acs |>
  summarise(total_occupied = sum(total_occupied),
            total_mh       = sum(total_mh),
            mh_pct = round(100 * sum(total_mh) /
                             sum(total_occupied), 2)) |>
  print()

write.csv(mh_acs,
  file.path(dir_out, "acs_mh_proportion_2024.csv"),
  row.names = FALSE)

