# ==============================================================
# 01_build_sample.R
# Draw the county-stratified building sample and compute
# inverse probability sampling weights
#
# For each state, the national structure inventory of Yang et al.
# (2024) is read from its file geodatabase, filtered to the three
# housing types of interest, and sampled within county by housing
# type. Counties containing fewer than min_mh manufactured homes
# are excluded, because the within-county comparison that the
# regression models rely on is not meaningful where manufactured
# housing is almost absent. Up to n_sample buildings of each
# housing type are then drawn at random in each remaining county,
# and each sampled building is assigned an inverse probability
# weight equal to the total number of buildings of that type in
# the county divided by the number selected.
#
# Inputs:
#   data/structures/Deliverable<date><ST>/
#     Deliverable<date><ST>/<ST>_Structures.gdb
#
# Outputs:
#   output/sampling/<ST>_sample.csv     one file per state
#   data/all_states_sample.csv          combined sample
#   data/all_states_sample.gpkg         combined sample as points
#
# This script is self-contained: it can be run on its own, or
# after 00_setup.R, in which case it reuses the paths that script
# defines. It is slow (several hours) and writes each state as it
# completes, so an interrupted run can be restarted and will skip
# states already finished.
# ==============================================================

library(sf)
library(dplyr)
library(purrr)
library(readr)
library(tibble)
library(tidyr)
library(stringr)

# ---- Paths ---------------------------------------------------
# Paths are relative to the project root. If 00_setup.R has
# already been sourced, the values it defined are kept.

if (!exists("dir_data")) dir_data <- "data"
if (!exists("dir_out"))  dir_out  <- "output"
if (!exists("crs_wgs84")) crs_wgs84 <- 4326

dir_structures <- file.path(dir_data, "structures")
dir_sampling   <- file.path(dir_out, "sampling")

dir.create(dir_sampling, showWarnings = FALSE, recursive = TRUE)

cat("Structure inventory:", dir_structures, "\n")
cat("Sample output:      ", dir_sampling, "\n")

# ---- Sampling parameters -------------------------------------
# n_sample: maximum buildings drawn per county per housing type
# min_mh:   minimum manufactured homes a county must contain to
#           be retained in the sample
# seed:     fixed so the draw is reproducible

n_sample    <- 500
min_mh      <- 10
sample_seed <- 1234

# ---- Housing type crosswalk ----------------------------------
# PRIM_OCC strings as they appear in the structure inventory.
# Note the spaces around the dash in the multi-family string.

keep_types <- c(
  "Manufactured Home",
  "Single Family Dwelling",
  "Multi - Family Dwelling"
)

type_crosswalk <- c(
  "Manufactured Home"       = "MH",
  "Single Family Dwelling"  = "Single Family",
  "Multi - Family Dwelling" = "Multi-Family"
)

# ---- State geodatabase release dates -------------------------
# The inventory is distributed as one geodatabase per state, each
# in a folder named for its release date. Alaska is not included
# because the analysis covers the contiguous United States;
# Hawaii and the District of Columbia are processed here but
# receive no region assignment and therefore drop out of all
# downstream analysis.

state_configs <- tribble(
  ~abbrev, ~date,
  "AZ", "20230502", "CA", "20230728", "TX", "20230630",
  "OK", "20231003", "AL", "20250606", "AR", "20230630",
  "CO", "20230630", "CT", "20230502", "DE", "20230630",
  "FL", "20230630", "GA", "20230526", "HI", "20230502",
  "ID", "20230526", "IL", "20230831", "IN", "20230502",
  "IA", "20230502", "KS", "20230630", "KY", "20230728",
  "LA", "20230630", "ME", "20230502", "MD", "20230728",
  "MA", "20230502", "MI", "20230526", "MN", "20230728",
  "MS", "20230630", "MO", "20230728", "MT", "20230502",
  "NE", "20230831", "NV", "20230526", "NH", "20230526",
  "NJ", "20230502", "NM", "20230502", "NY", "20230502",
  "NC", "20230502", "ND", "20230728", "OH", "20230502",
  "OR", "20230526", "PA", "20230831", "RI", "20230502",
  "SC", "20230526", "SD", "20230728", "TN", "20230502",
  "UT", "20230502", "VA", "20230502", "VT", "20230502",
  "WA", "20230831", "WV", "20230831", "WI", "20230728",
  "WY", "20230728", "DC", "20230502"
)

cat("States to process:", nrow(state_configs), "\n")

# ---- Path helpers --------------------------------------------
# Each geodatabase sits inside two nested folders of the same
# name, for example
#   data/structures/Deliverable20230502AZ/
#     Deliverable20230502AZ/AZ_Structures.gdb

make_gdb_path <- function(abbrev, date, dir = dir_structures) {
  folder_name <- paste0("Deliverable", date, abbrev)
  file.path(dir, folder_name, folder_name,
            paste0(abbrev, "_Structures.gdb"))
}

make_layer_name <- function(abbrev) paste0(abbrev, "_Structures")

# ---- Process one state ---------------------------------------
process_state <- function(abbrev, date) {

  message("\n== ", abbrev, " == ",
          format(Sys.time(), "%H:%M:%S"))

  gdb_path   <- make_gdb_path(abbrev, date)
  layer_name <- make_layer_name(abbrev)
  out_path   <- file.path(dir_sampling,
                          paste0(abbrev, "_sample.csv"))

  if (file.exists(out_path)) {
    message("Already processed, skipping")
    return(invisible(NULL))
  }
  if (!file.exists(gdb_path)) {
    message("Geodatabase not found: ", gdb_path)
    return(invisible(NULL))
  }

  t0 <- Sys.time()

  # Read only the needed attributes and drop the polygon
  # geometry immediately; centroid coordinates are already
  # present as columns
  bldg_df <- tryCatch({
    st_read(gdb_path, layer = layer_name,
            query = paste0(
              "SELECT UUID, OCC_CLS, PRIM_OCC, CENSUSCODE,
                      SQFEET, LATITUDE, LONGITUDE
               FROM ", layer_name),
            quiet = TRUE) |>
      st_drop_geometry()
  }, error = function(e) {
    message("Read failed: ", conditionMessage(e)); NULL
  })

  if (is.null(bldg_df) || nrow(bldg_df) == 0) {
    message("No data for ", abbrev)
    return(invisible(NULL))
  }

  message("Rows read: ", format(nrow(bldg_df), big.mark = ","),
          " | ", round(difftime(Sys.time(), t0,
                                units = "mins"), 1), " mins")

  # Filter to the three housing types and drop records with no
  # coordinates
  bldg_df <- bldg_df |>
    filter(PRIM_OCC %in% keep_types,
           !is.na(LATITUDE), !is.na(LONGITUDE))

  if (nrow(bldg_df) == 0) {
    message("No matching housing types for ", abbrev)
    return(invisible(NULL))
  }

  # Classify and derive FIPS codes.
  # CENSUSCODE is an 11-digit tract identifier: positions 1 to 2
  # give the state FIPS and positions 1 to 5 the county FIPS.
  bldg_df <- bldg_df |>
    mutate(
      Building     = unname(type_crosswalk[PRIM_OCC]),
      state_fips   = substr(CENSUSCODE, 1, 2),
      county_fips  = substr(CENSUSCODE, 1, 5),
      state_abbrev = abbrev
    ) |>
    filter(!is.na(Building))

  message("After type filter: ",
          format(nrow(bldg_df), big.mark = ","))
  print(table(bldg_df$Building))

  # Retain only counties with at least min_mh manufactured homes
  n_counties_before <- n_distinct(bldg_df$county_fips)

  eligible_counties <- bldg_df |>
    filter(Building == "MH") |>
    count(county_fips, name = "n_mh") |>
    filter(n_mh >= min_mh) |>
    pull(county_fips)

  message("Counties: ", n_counties_before, " total, ",
          length(eligible_counties), " with at least ", min_mh,
          " MH retained")

  if (length(eligible_counties) == 0) {
    message("No eligible counties for ", abbrev)
    return(invisible(NULL))
  }

  bldg_df <- bldg_df |>
    filter(county_fips %in% eligible_counties)

  # Stratified random sample: up to n_sample buildings of each
  # housing type in each county. Where a county holds fewer than
  # n_sample buildings of a type, all of them are taken.
  set.seed(sample_seed)

  sampled <- bldg_df |>
    group_by(county_fips, Building) |>
    slice_sample(n = n_sample, replace = FALSE) |>
    ungroup()

  message("Sampled: ", format(nrow(sampled), big.mark = ","))

  # Inverse probability weights.
  # weight = total_n / selected_n, the number of buildings in the
  # county of that type that each sampled building represents.
  # A weight of 1 means the county held at most n_sample
  # buildings of that type and all were included.
  county_counts   <- bldg_df |>
    count(county_fips, Building, name = "total_n")
  selected_counts <- sampled |>
    count(county_fips, Building, name = "selected_n")

  weights_df <- county_counts |>
    left_join(selected_counts,
              by = c("county_fips", "Building")) |>
    mutate(
      selected_n = coalesce(selected_n, 0L),
      weight     = ifelse(selected_n > 0,
                          total_n / selected_n, NA_real_)
    ) |>
    select(county_fips, Building, total_n, selected_n, weight)

  sampled_final <- sampled |>
    left_join(weights_df, by = c("county_fips", "Building")) |>
    select(
      UUID,          # unique building identifier
      Building,      # MH, Single Family or Multi-Family
      PRIM_OCC,      # original classification string
      OCC_CLS,       # broad occupancy class
      state_abbrev,  # two-letter state code
      state_fips,    # two-digit state FIPS
      county_fips,   # five-digit county FIPS
      CENSUSCODE,    # eleven-digit tract code
      SQFEET,        # building footprint area
      LATITUDE,      # centroid latitude (WGS84)
      LONGITUDE,     # centroid longitude (WGS84)
      total_n,       # buildings of this type in the county
      selected_n,    # buildings of this type sampled
      weight         # total_n / selected_n
    )

  write_csv(sampled_final, out_path)

  message("Saved ", basename(out_path), " | ",
          format(nrow(sampled_final), big.mark = ","),
          " rows | ",
          round(difftime(Sys.time(), t0, units = "mins"), 1),
          " mins")

  rm(bldg_df, sampled, sampled_final,
     county_counts, selected_counts, weights_df)
  gc()

  invisible(NULL)
}

# ---- Run all states ------------------------------------------
cat("\nProcessing states...\n")

walk2(state_configs$abbrev, state_configs$date,
      function(abbrev, date) {
        i <- which(state_configs$abbrev == abbrev)
        message("[", i, "/", nrow(state_configs), "] ", abbrev)
        tryCatch(process_state(abbrev, date),
                 error = function(e) {
                   message("FAILED: ", abbrev, " | ",
                           conditionMessage(e))
                 })
      })

completed <- list.files(dir_sampling,
                        pattern = "_sample\\.csv$") |>
  str_remove("_sample\\.csv$")

cat("\nCompleted:", length(completed), "of",
    nrow(state_configs), "states\n")

missing <- setdiff(state_configs$abbrev, completed)
if (length(missing) > 0) {
  cat("Missing:", paste(missing, collapse = ", "), "\n")
}

# ---- Combine state samples -----------------------------------
# FIPS codes are read as character throughout so that leading
# zeros are preserved.

cat("\nCombining state samples...\n")

all_samples <- map_dfr(
  list.files(dir_sampling, pattern = "_sample\\.csv$",
             full.names = TRUE),
  ~ read_csv(.x, col_types = cols(
      UUID         = col_character(),
      Building     = col_character(),
      PRIM_OCC     = col_character(),
      OCC_CLS      = col_character(),
      state_abbrev = col_character(),
      state_fips   = col_character(),
      county_fips  = col_character(),
      CENSUSCODE   = col_character(),
      SQFEET       = col_double(),
      LATITUDE     = col_double(),
      LONGITUDE    = col_double(),
      total_n      = col_double(),
      selected_n   = col_double(),
      weight       = col_double()
    ))
)

cat("Total buildings:",
    format(nrow(all_samples), big.mark = ","), "\n")
cat("Counties represented:",
    n_distinct(all_samples$county_fips), "\n\n")

cat("By housing type:\n")
print(table(all_samples$Building))

cat("\nBy state and housing type:\n")
all_samples |>
  count(state_abbrev, Building) |>
  pivot_wider(names_from = Building, values_from = n,
              values_fill = 0) |>
  arrange(state_abbrev) |>
  print(n = 51)

cat("\nSampling weights by housing type:\n")
all_samples |>
  group_by(Building) |>
  summarise(
    mean_weight   = round(mean(weight,   na.rm = TRUE), 2),
    median_weight = round(median(weight, na.rm = TRUE), 2),
    max_weight    = round(max(weight,    na.rm = TRUE), 2),
    pct_weight_1  = round(mean(weight == 1,
                               na.rm = TRUE) * 100, 1),
    .groups = "drop"
  ) |>
  print()

# Leading zeros must survive the round trip
stopifnot(
  is.character(all_samples$state_fips),
  all(nchar(all_samples$state_fips)  == 2),
  all(nchar(all_samples$county_fips) == 5)
)

write_csv(all_samples,
          file.path(dir_data, "all_states_sample.csv"))

cat("\nSaved all_states_sample.csv\n")

# ---- Spatial version -----------------------------------------
# GeoPackage rather than shapefile: no column name truncation,
# a single file, and faster to read and write.

all_samples_sf <- all_samples |>
  st_as_sf(coords = c("LONGITUDE", "LATITUDE"),
           crs = crs_wgs84, remove = FALSE)

st_write(all_samples_sf,
         file.path(dir_data, "all_states_sample.gpkg"),
         layer = "buildings", delete_dsn = TRUE, quiet = TRUE)

cat("Saved all_states_sample.gpkg\n")
cat("\nDone.\n")
