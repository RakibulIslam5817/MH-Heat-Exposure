

# 07_robustness.R
# Spatial autocorrelation diagnostics and Conley standard errors
#
# Residual spatial autocorrelation is tested with Moran's I on a
# k = 8 nearest-neighbour weights matrix built from projected
# building coordinates (EPSG:5070). Because Moran's I values are
# high, all primary specifications are re-estimated with Conley
# standard errors, which allow residual correlation to decay
# with geographic distance up to a 50 km cutoff. County fixed
# effects are retained; only the variance estimator changes, so
# point estimates are identical across the two specifications.
#
# Inputs:
#   output/regression/reg_mh_sf_dataset.csv
#   output/regression/reg_mh_mf_dataset.csv
#   output/regression/cooling_reg_df.csv
#
# Outputs:
#   output/regression/morans_i_heat.csv
#   output/regression/morans_i_cooling.csv
#   output/regression/conley_heat_results.csv     
#   output/regression/conley_cooling_results.csv  
#
# Run 00_setup.R, 05_heat_regressions.R and
# 06_cooling_centers.R first.


library(RANN)

read_reg <- function(f) {
  read_csv(file.path(dir_out, "regression", f),
           col_types = cols(
             UUID        = col_character(),
             Building    = col_character(),
             state_fips  = col_character(),
             county_fips = col_character(),
             region      = col_character(),
             .default    = col_guess())) |>
    mutate(region = factor(region, levels = regions))
}

reg_mh_sf      <- read_reg("reg_mh_sf_dataset.csv") |>
  mutate(Building = factor(Building,
                           levels = c("Single Family", "MH")),
         county_fips = factor(county_fips))
reg_mh_mf      <- read_reg("reg_mh_mf_dataset.csv") |>
  mutate(Building = factor(Building,
                           levels = c("Multi-Family", "MH")),
         county_fips = factor(county_fips))
cooling_reg_df <- read_reg("cooling_reg_df.csv")

cooling_mh_sf <- cooling_reg_df |>
  filter(Building %in% c("MH", "Single Family")) |>
  mutate(Building = factor(Building,
                           levels = c("Single Family", "MH")),
         county_fips = factor(county_fips))
cooling_mh_mf <- cooling_reg_df |>
  filter(Building %in% c("MH", "Multi-Family")) |>
  mutate(Building = factor(Building,
                           levels = c("Multi-Family", "MH")),
         county_fips = factor(county_fips))

# ---- Model fitting helpers -----------------------------------
fit_clustered <- function(fml, data, estimator = "ols") {
  if (estimator == "ols") {
    feols(fml, data = data, weights = ~ weight,
          cluster = ~ county_fips, fixef.rm = "singleton")
  } else {
    fepois(fml, data = data, weights = ~ weight,
           cluster = ~ county_fips, fixef.rm = "singleton")
  }
}

fit_conley <- function(fml, data, estimator = "ols",
                        cutoff = 50) {
  vc <- vcov_conley(lat = "LATITUDE", lon = "LONGITUDE",
                    cutoff = cutoff)
  if (estimator == "ols") {
    feols(fml, data = data, weights = ~ weight,
          vcov = vc, fixef.rm = "singleton")
  } else {
    fepois(fml, data = data, weights = ~ weight,
           vcov = vc, fixef.rm = "singleton")
  }
}

make_fml <- function(outcome_var) {
  as.formula(paste0(outcome_var, " ~ Building + ",
                    control_formula, " | county_fips"))
}

# ---- Moran's I -----------------------------------------------
run_moran <- function(model, data_df, outcome_label,
                       group_label, k = 8) {

  coords  <- project_coords(data_df$LONGITUDE, data_df$LATITUDE)
  res     <- get_resid(model, data_df)
  resid_v <- res$resid
  kept    <- res$kept

  nb <- knn2nb(knearneigh(coords[kept, , drop = FALSE], k = k))
  lw <- nb2listw(nb, style = "W")
  mi <- moran.test(resid_v, lw, randomisation = TRUE)

  tibble(
    group    = group_label,
    outcome  = outcome_label,
    n_obs    = length(resid_v),
    morans_i = round(mi$estimate["Moran I statistic"], 4),
    expected = round(mi$estimate["Expectation"], 6),
    z_score  = round(mi$statistic, 4),
    p_value  = mi$p.value,
    sig      = sig_stars(mi$p.value)
  )
}

# Heat models, by region, MH vs single family
moran_outcomes <- list(
  list(var = "p95_tmax", label = "p95 Tmax", model = "ols"),
  list(var = "cdd_18",   label = "CDD",      model = "ols"),
  list(var = "exc_p95",  label = "Exc p95",  model = "pois")
)

cat("Moran's I for the heat models...\n")

moran_heat <- map_dfr(regions, function(r) {
  df <- reg_mh_sf |>
    filter(region == r, !is.na(LATITUDE), !is.na(LONGITUDE))
  if (nrow(df) == 0) return(NULL)
  cat("  ", r, "| n =", format(nrow(df), big.mark = ","), "\n")

  map_dfr(moran_outcomes, function(ov) {
    tryCatch({
      m <- fit_clustered(make_fml(ov$var), df, ov$model)
      run_moran(m, df, ov$label, r)
    }, error = function(e) {
      cat("    failed:", ov$label, "\n"); NULL
    })
  })
})

print(moran_heat, n = 30, width = Inf)

write.csv(moran_heat,
  file.path(dir_out, "regression", "morans_i_heat.csv"),
  row.names = FALSE)

# Cooling accessibility models, national
cat("\nMoran's I for the cooling accessibility models...\n")

moran_cooling <- bind_rows(
  run_moran(fit_clustered(make_fml("log_dist"), cooling_mh_sf),
            cooling_mh_sf, "log(dist_km)",
            "MH vs Single Family"),
  run_moran(fit_clustered(make_fml("covered_walk"),
                          cooling_mh_sf),
            cooling_mh_sf, "covered_walk",
            "MH vs Single Family"),
  run_moran(fit_clustered(make_fml("log_dist"), cooling_mh_mf),
            cooling_mh_mf, "log(dist_km)",
            "MH vs Multi-Family"),
  run_moran(fit_clustered(make_fml("covered_walk"),
                          cooling_mh_mf),
            cooling_mh_mf, "covered_walk",
            "MH vs Multi-Family")
)

print(moran_cooling, width = Inf)

write.csv(moran_cooling,
  file.path(dir_out, "regression", "morans_i_cooling.csv"),
  row.names = FALSE)

# ---- Conley standard errors ----------------------------------
extract_se <- function(model, outcome_label, group_label,
                        comparison_label, se_type_label) {
  tidy(model) |>
    filter(str_detect(term, "BuildingMH")) |>
    mutate(
      comparison = comparison_label,
      group      = group_label,
      outcome    = outcome_label,
      se_type    = se_type_label,
      sig        = sig_stars(p.value)
    ) |>
    select(comparison, group, outcome, se_type, estimate,
           std.error, statistic, p.value, sig) |>
    mutate(across(where(is.numeric) & !any_of("p.value"),
                  ~ round(.x, 6)))
}

run_se_comparison <- function(data, ov, group_label,
                               comparison_label) {
  df <- if (group_label == "National") {
    data
  } else {
    filter(data, region == group_label)
  }
  if (nrow(df) == 0) return(NULL)

  fml <- make_fml(ov$var)

  tryCatch({
    bind_rows(
      extract_se(fit_clustered(fml, df, ov$model), ov$label,
                 group_label, comparison_label,
                 "County-clustered"),
      extract_se(fit_conley(fml, df, ov$model), ov$label,
                 group_label, comparison_label, "Conley 50km")
    )
  }, error = function(e) {
    cat("  failed:", group_label, ov$var, "\n"); NULL
  })
}

all_levels <- c("National", regions)

cat("\nConley standard errors, heat models...\n")

conley_heat <- bind_rows(
  map_dfr(moran_outcomes, function(ov) {
    cat("  MH vs SF |", ov$label, "\n")
    map_dfr(all_levels, ~ run_se_comparison(
      reg_mh_sf, ov, .x, "MH vs Single Family"))
  }),
  map_dfr(moran_outcomes, function(ov) {
    cat("  MH vs MF |", ov$label, "\n")
    map_dfr(all_levels, ~ run_se_comparison(
      reg_mh_mf, ov, .x, "MH vs Multi-Family"))
  })
)

print(conley_heat, n = 100, width = Inf)

write.csv(conley_heat,
  file.path(dir_out, "regression", "conley_heat_results.csv"),
  row.names = FALSE)

cat("\nConley standard errors, cooling models...\n")

cooling_outcomes <- list(
  list(var = "log_dist",     label = "log(dist_km)",
       model = "ols"),
  list(var = "covered_walk", label = "covered_walk",
       model = "ols")
)

conley_cooling <- bind_rows(
  map_dfr(cooling_outcomes, ~ run_se_comparison(
    cooling_mh_sf, .x, "National", "MH vs Single Family")),
  map_dfr(cooling_outcomes, ~ run_se_comparison(
    cooling_mh_mf, .x, "National", "MH vs Multi-Family"))
)

print(conley_cooling, width = Inf)

write.csv(conley_cooling,
  file.path(dir_out, "regression", "conley_cooling_results.csv"),
  row.names = FALSE)

# ---- Robustness summary --------------------------------------
# Point estimates are identical across the two variance
# estimators; only standard errors and p-values differ. The
# summary below reports whether results that were significant
# under county-clustered errors remain significant under Conley
# standard errors.

summarise_robustness <- function(results) {
  results |>
    select(comparison, group, outcome, se_type, estimate,
           std.error, p.value, sig) |>
    pivot_wider(names_from  = se_type,
                values_from = c(std.error, p.value, sig),
                names_glue  = "{se_type}_{.value}") |>
    rename_with(~ str_replace_all(.x, " ", "_")) |>
    filter(`County-clustered_sig` %in% c("***", "**", "*", ".")) |>
    mutate(robust = case_when(
      `Conley_50km_sig` %in% c("***", "**", "*") ~ "Robust",
      `Conley_50km_sig` == "."                   ~ "Marginal",
      TRUE                                        ~ "Lost significance"
    )) |>
    arrange(comparison, outcome, group)
}

print(summarise_robustness(conley_heat), n = 40, width = Inf)

print(summarise_robustness(conley_cooling), width = Inf)
