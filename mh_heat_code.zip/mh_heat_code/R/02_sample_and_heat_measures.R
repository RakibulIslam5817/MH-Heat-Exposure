
# 01_sample_and_heat_measures.R
# Build the building-level heat exposure dataset
#
# Inputs:
#   data/all_states_sample.csv        county-stratified building
#                                     sample with IPW weights
#   data/PRISM_Raster/*.zip           PRISM daily Tmax, 800 m,
#                                     April to October 2024
#
# Outputs:
#   output/rasters/PRISM_tmax_p95_2024.tif
#   output/rasters/PRISM_tmax_p98_2024.tif
#   output/heat_measures/heat_measures_all.csv
#   output/heat_measures/regional_thresholds.csv
#
# Run 00_setup.R first.


########################### Load the building sample ###########################
# all_states_sample.csv contains one row per sampled building:
#   UUID, Building, PRIM_OCC, OCC_CLS, state_abbrev, state_fips,
#   county_fips, CENSUSCODE, SQFEET, LATITUDE, LONGITUDE,
#   total_n, selected_n, weight
#
# Sampling design: up to 500 buildings per housing type per
# county, with inverse probability weights
#   weight = total_n / selected_n

cat("Loading building sample...\n")

all_samples <- read_csv(
  file.path(dir_data, "all_states_sample.csv"),
  col_types = cols(
    UUID         = col_character(),
    Building     = col_character(),
    PRIM_OCC     = col_character(),
    OCC_CLS      = col_character(),
    state_abbrev = col_character(),
    state_fips   = col_character(),
    county_fips  = col_character(),
    CENSUSCODE   = col_character(),
    SQFEET       = col_double(),
    LATITUDE     = col_double(),
    LONGITUDE    = col_double(),
    total_n      = col_double(),
    selected_n   = col_double(),
    weight       = col_double()
  )
) |>
  mutate(region = assign_region(state_fips))

cat("Total buildings:",
    format(nrow(all_samples), big.mark = ","), "\n")
print(table(all_samples$Building))
print(table(all_samples$region))
cat("Unassigned region:", sum(is.na(all_samples$region)), "\n")

########################### Build the PRISM daily raster stack ###########################
cat("\nBuilding PRISM daily Tmax stack...\n")

zip_daily <- list.files(
  dir_prism,
  pattern    = "^prism_tmax_us_30s_\\d{8}\\.zip$",
  full.names = TRUE
)

zip_dates <- str_extract(basename(zip_daily), "\\d{8}")
zip_daily <- zip_daily[order(zip_dates)]
zip_dates <- sort(zip_dates)

cat("Daily PRISM files found:", length(zip_daily), "\n")

zip_tif_df <- map_dfr(zip_daily, function(zf) {
  zinfo     <- unzip(zf, list = TRUE)
  tif_names <- zinfo$Name[str_detect(zinfo$Name, "\\.tif$|\\.tiff$")]
  if (length(tif_names) == 0) return(NULL)
  data.frame(
    zip_path = zf,
    tif_name = tif_names[1],
    zip_date = str_extract(basename(zf), "\\d{8}"),
    stringsAsFactors = FALSE
  )
})

# Read the GeoTIFFs directly from inside the zip archives
vsi_paths <- file.path(
  "/vsizip",
  gsub("\\\\", "/", zip_tif_df$zip_path),
  zip_tif_df$tif_name
)

r_stack        <- terra::rast(vsi_paths)
names(r_stack) <- paste0("tmax_", zip_tif_df$zip_date)

cat("Stack layers:", terra::nlyr(r_stack), "\n")
cat("Resolution:", terra::res(r_stack), "\n")

########################### Pixel-level percentile rasters ###########################
# The 95th and 98th percentile of daily Tmax at each PRISM pixel
# across the 2024 warm season.

p98_path <- file.path(dir_out, "rasters", "PRISM_tmax_p98_2024.tif")
p95_path <- file.path(dir_out, "rasters", "PRISM_tmax_p95_2024.tif")

make_percentile_raster <- function(stack, prob, out_path) {
  if (file.exists(out_path)) {
    cat("Loading saved raster:", basename(out_path), "\n")
    return(terra::rast(out_path))
  }
  cat("Computing", basename(out_path), "...\n")
  r <- terra::app(
    stack,
    fun   = function(x) quantile(x, probs = prob, na.rm = TRUE),
    cores = 4
  )
  terra::writeRaster(r, out_path, overwrite = TRUE)
  r
}

tmax_p98_raster <- make_percentile_raster(r_stack, 0.98, p98_path)
tmax_p95_raster <- make_percentile_raster(r_stack, 0.95, p95_path)

########################### Extract raster values at building locations ###########################
cat("\nExtracting PRISM values at building locations...\n")

sampled_vect <- all_samples |>
  st_as_sf(coords = c("LONGITUDE", "LATITUDE"), crs = crs_wgs84) |>
  st_transform(crs = terra::crs(tmax_p98_raster)) |>
  terra::vect()

ext_p98 <- terra::extract(tmax_p98_raster, sampled_vect,
                          method = "simple")
ext_p95 <- terra::extract(tmax_p95_raster, sampled_vect,
                          method = "simple")

cat("NA rate p98:", round(mean(is.na(ext_p98[, 2])) * 100, 1), "%\n")
cat("NA rate p95:", round(mean(is.na(ext_p95[, 2])) * 100, 1), "%\n")

rm(tmax_p98_raster, tmax_p95_raster)
gc()

# Full daily stack, used for exceedance days and CDD
cat("Extracting daily Tmax stack (this takes some time)...\n")
t0 <- Sys.time()
ext_daily <- terra::extract(r_stack, sampled_vect, method = "simple")
cat("Done in:",
    round(difftime(Sys.time(), t0, units = "mins"), 1), "mins\n")
cat("Dimensions:", nrow(ext_daily), "buildings x",
    ncol(ext_daily) - 1, "days\n")

########################### Assemble the base heat measures ###########################
heat_measures <- all_samples |>
  mutate(
    p98_tmax = ext_p98[, 2],
    p95_tmax = ext_p95[, 2]
  ) |>
  filter(!is.na(p98_tmax), !is.na(p95_tmax))

cat("\nBuildings with valid heat values:",
    format(nrow(heat_measures), big.mark = ","), "\n")
cat("Dropped (outside raster extent):",
    format(nrow(all_samples) - nrow(heat_measures),
           big.mark = ","), "\n")

valid_rows   <- which(!is.na(ext_p98[, 2]) & !is.na(ext_p95[, 2]))
daily_matrix <- as.matrix(ext_daily[valid_rows, -1])
stopifnot(nrow(daily_matrix) == nrow(heat_measures))

########################### Regional exceedance thresholds ###########################
# For each region, all building-day Tmax observations are pooled,
# weighted by the building sampling weight, and the 95th and 98th
# percentiles of that pooled distribution are taken as the
# region-specific extreme heat thresholds.

compute_regional_threshold <- function(region_name, probs = 0.98) {

  region_rows <- which(heat_measures$region == region_name)
  if (length(region_rows) == 0) {
    cat("No buildings in region:", region_name, "\n")
    return(NA_real_)
  }

  region_daily   <- daily_matrix[region_rows, ]
  region_weights <- heat_measures$weight[region_rows]

  all_vals <- as.vector(region_daily)
  all_wts  <- rep(region_weights, times = ncol(region_daily))

  keep     <- !is.na(all_vals) & !is.na(all_wts) &
                is.finite(all_wts) & all_wts > 0
  all_vals <- all_vals[keep]
  all_wts  <- all_wts[keep]

  ord      <- order(all_vals)
  all_vals <- all_vals[ord]
  all_wts  <- all_wts[ord]
  cum_wts  <- cumsum(all_wts) / sum(all_wts)

  threshold <- all_vals[which(cum_wts >= probs)[1]]

  cat(region_name, "| n buildings:", length(region_rows),
      "| p", probs * 100, "threshold:",
      round(threshold, 2), "°C\n")

  threshold
}

cat("\nRegional p98 thresholds:\n")
regional_thresh_p98 <- map_dbl(regions,
  ~ compute_regional_threshold(.x, probs = 0.98))
names(regional_thresh_p98) <- regions

cat("\nRegional p95 thresholds:\n")
regional_thresh_p95 <- map_dbl(regions,
  ~ compute_regional_threshold(.x, probs = 0.95))
names(regional_thresh_p95) <- regions

threshold_table <- data.frame(
  region        = regions,
  threshold_p98 = round(regional_thresh_p98, 2),
  threshold_p95 = round(regional_thresh_p95, 2)
)
print(threshold_table)

write.csv(threshold_table,
  file.path(dir_out, "heat_measures", "regional_thresholds.csv"),
  row.names = FALSE)

######### Exceedance days and cooling degree days #########
# exc_p98, exc_p95: number of warm-season days on which a
#   building's pixel-level daily Tmax exceeded its regional
#   threshold
# cdd_18: sum of positive differences between daily Tmax and
#   18.3 C across the warm season

heat_measures <- heat_measures |>
  mutate(
    reg_thresh_p98 = regional_thresh_p98[region],
    reg_thresh_p95 = regional_thresh_p95[region]
  )

exc_p98 <- rowSums(
  sweep(daily_matrix, 1, heat_measures$reg_thresh_p98, FUN = ">"),
  na.rm = TRUE
)
exc_p95 <- rowSums(
  sweep(daily_matrix, 1, heat_measures$reg_thresh_p95, FUN = ">"),
  na.rm = TRUE
)
cdd_18 <- rowSums(pmax(daily_matrix - CDD_BASE, 0), na.rm = TRUE)

heat_measures <- heat_measures |>
  mutate(exc_p98 = exc_p98,
         exc_p95 = exc_p95,
         cdd_18  = cdd_18)

cat("\nHeat measures by building type:\n")
heat_measures |>
  group_by(Building) |>
  summarise(
    mean_p98     = wmean(p98_tmax, weight),
    mean_p95     = wmean(p95_tmax, weight),
    mean_exc_p98 = wmean(exc_p98,  weight),
    mean_exc_p95 = wmean(exc_p95,  weight),
    mean_cdd_18  = wmean(cdd_18,   weight),
    .groups      = "drop"
  ) |>
  print()

write.csv(heat_measures,
  file.path(dir_out, "heat_measures", "heat_measures_all.csv"),
  row.names = FALSE)

