# 00_setup.R
# Paths, packages, constants, and shared helper functions
#
# Source this script first. All other scripts assume the objects
# defined here are in the environment.


# ---- Packages ------------------------------------------------
library(terra)
library(sf)
library(dplyr)
library(tidyr)
library(purrr)
library(stringr)
library(readr)
library(ggplot2)
library(scales)
library(patchwork)
library(cowplot)
library(RColorBrewer)
library(fixest)
library(broom)
library(tidycensus)
library(tigris)
library(reldist)
library(spdep)

options(tigris_use_cache = TRUE)

# ---- Paths ---------------------------------------------------
# Relative to the project root. Set the working directory to the
# project root before sourcing, or edit dir_root below.

dir_root    <- "."
dir_data    <- file.path(dir_root, "data")
dir_prism   <- file.path(dir_data, "PRISM_Raster")
dir_cooling <- file.path(dir_data, "cooling")
dir_out     <- file.path(dir_root, "output")

subdirs <- c("rasters", "sampling", "extractions",
             "heat_measures", "cdf_gini", "regression",
             "maps", "shap")

walk(file.path(dir_out, subdirs), dir.create,
     showWarnings = FALSE, recursive = TRUE)

# ---- Census API key ------------------------------------------
# Supply your own key via an environment variable. Request one at
# https://api.census.gov/data/key_signup.html and add the line
#   CENSUS_API_KEY=your_key_here
# to a .Renviron file in the project root.

census_api_key(Sys.getenv("CENSUS_API_KEY"), install = FALSE)

# ---- Region classification -----------------------------------
# Seven regions grouped for broadly similar warm-season climate,
# adapted from the NCA5 climate regions (USGCRP 2023). 

northwest_states  <- c("53", "41", "30", "16", "56")
southwest_states  <- c("06", "32", "49", "04", "08", "35")
midwest_states    <- c("38", "46", "31", "20", "27", "19", "29")
greatlakes_states <- c("55", "26", "17", "18", "39", "21")
south_states      <- c("40", "48", "22", "05")
southeast_states  <- c("47", "37", "45", "51", "54", "13",
                       "01", "28", "12")
newengland_states <- c("23", "50", "33", "25", "44", "09",
                       "36", "34", "42", "24", "10")

assign_region <- function(state_fips) {
  state_fips <- formatC(as.integer(state_fips),
                        width = 2, flag = "0")
  case_when(
    state_fips %in% northwest_states  ~ "Northwest",
    state_fips %in% southwest_states  ~ "Southwest",
    state_fips %in% midwest_states    ~ "Midwest",
    state_fips %in% greatlakes_states ~ "Great Lakes",
    state_fips %in% south_states      ~ "South",
    state_fips %in% southeast_states  ~ "Southeast",
    state_fips %in% newengland_states ~ "New England",
    TRUE                              ~ NA_character_
  )
}

regions <- c("Northwest", "Southwest", "Midwest",
             "Great Lakes", "South", "Southeast",
             "New England")

geos <- c("National", regions)

# ---- Analysis constants --------------------------------------
building_levels <- c("MH", "Single Family", "Multi-Family")

building_colors <- c(
  "MH"            = "#C0392B",
  "Single Family" = "#1A5276",
  "Multi-Family"  = "#5DADE2"
)

all_measures <- c("p98_tmax", "p95_tmax",
                  "exc_p98", "exc_p95", "cdd_18")

measure_labels <- c(
  p98_tmax = "p98 Tmax (°C)",
  p95_tmax = "p95 Tmax (°C)",
  exc_p98  = "Exc Days (p98)",
  exc_p95  = "Exc Days (p95)",
  cdd_18   = "CDD (>18.3°C)"
)

# Cooling degree day base temperature, 18.3 C (65 F), the
# standard United States cooling energy demand threshold
# (Petri and Caldeira 2015)
CDD_BASE <- 18.3

# Cooling center accessibility thresholds
# 0.8 km corresponds to the 0.5 mile walking threshold derived
# from OSHA occupational heat safety guidance (Nayak et al. 2019)
walk_threshold_km  <- 0.8
drive_threshold_km <- 16.1

# Projected coordinate system for distance calculations
# EPSG:5070, NAD83 / Conus Albers (units: metres)
crs_albers <- 5070
crs_wgs84  <- 4326

# Regression control variables
controls <- c(
  "pop_density", "share_nh_white", "share_hispanic",
  "share_immigrant", "median_hh_income", "unemp_rate",
  "poverty_rate", "homeown_rate", "median_yr_built",
  "is_urban_bg"
)
control_formula <- paste(controls, collapse = " + ")

# ---- Shared helper functions ---------------------------------

# Weighted empirical cumulative distribution function.
# Generalises the standard empirical CDF to unequal sampling
# weights: the weighted count of observations at or below each
# value is divided by the total weight.
weighted_cdf <- function(values, weights) {
  keep  <- !is.na(values) & !is.na(weights) &
            is.finite(weights) & weights > 0
  vals  <- values[keep]
  wts   <- weights[keep]
  ord   <- order(vals)
  vals  <- vals[ord]
  wts   <- wts[ord]
  data.frame(x = vals, cdf = cumsum(wts) / sum(wts))
}

# Weighted Gini coefficient by building type, plus all buildings
# pooled. Uses reldist::gini.
compute_group_gini <- function(data, var) {
  gini_one <- function(d) {
    round(reldist::gini(d[[var]], weights = d$weight), 4)
  }

  group_gini <- data |>
    group_by(Building) |>
    group_modify(~ tibble(gini = gini_one(.x))) |>
    ungroup() |>
    rename(Group = Building)

  bind_rows(
    tibble(Group = "All buildings", gini = gini_one(data)),
    group_gini
  ) |>
    mutate(measure = var)
}

# Weighted mean, rounded
wmean <- function(values, weights) {
  round(weighted.mean(values, weights, na.rm = TRUE), 2)
}

# Weighted share of buildings at or above a threshold
pct_above_thresh <- function(values, weights, thr) {
  round(weighted.mean(values >= thr, weights,
                      na.rm = TRUE) * 100, 1)
}

# Project longitude and latitude to EPSG:5070 coordinates
project_coords <- function(lon, lat) {
  st_as_sf(data.frame(lon = lon, lat = lat),
           coords = c("lon", "lat"),
           crs    = crs_wgs84) |>
    st_transform(crs = crs_albers) |>
    st_coordinates()
}

# Residuals from a fixest model, with the row indices retained
# after singleton and missing-value removal
get_resid <- function(model, data_df) {
  removed     <- model$obs_selection$obsRemoved
  removed_pos <- if (length(removed) == 0) integer(0) else abs(removed)
  kept        <- setdiff(seq_len(nrow(data_df)), removed_pos)
  list(resid = residuals(model), kept = kept)
}

# Significance stars
sig_stars <- function(p) {
  case_when(
    p < 0.001 ~ "***",
    p < 0.01  ~ "**",
    p < 0.05  ~ "*",
    p < 0.1   ~ ".",
    TRUE      ~ "ns"
  )
}


